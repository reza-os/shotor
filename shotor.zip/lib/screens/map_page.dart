import 'dart:async';
     import 'dart:convert';
     import 'dart:math' as math;
     import 'dart:io';
     import 'map_dashboard_components.dart';
     import 'online_herd_map.dart';
     import '../services/map_herd_status.dart';
     import '../services/map_data_events.dart';
     import '../services/map_cluster_service.dart';
     import '../services/record_day_service.dart';

     import 'package:flutter/material.dart';
     import 'package:flutter/foundation.dart' show listEquals;
     import 'package:flutter/services.dart';
     import 'package:url_launcher/url_launcher.dart';

     import '../models/area_zone.dart';
     import '../models/geo_area.dart';
     import '../models/polygon_zone.dart';
     import '../models/tag_record.dart';
     import '../utils/jalali_date_ui.dart';
     import '../utils/iran_time.dart';
     import '../services/area_zone_service.dart';
     import '../services/current_geo_area_service.dart';
     import '../services/local_storage_service.dart';
     import '../services/tag_records_events.dart';
     import '../services/location_service.dart';
     import '../services/polygon_zone_service.dart';
     import '../services/zone_check_service.dart';

     import 'polygon_zone_form_page.dart';
     import 'package:file_picker/file_picker.dart';
     import '../models/geo_point.dart';
     import '../services/kml_import_service.dart';
     import '../services/geo_area_service.dart';
     import '../models/camel_detail.dart';
     import '../services/camel_detail_service.dart';




     BoxDecoration _mapCardDecoration({
       Color color = Colors.white,
       double radius = 20,
       bool bordered = false,
     }) {
       return BoxDecoration(
         color: color,
         borderRadius: BorderRadius.circular(radius),
         border: bordered
             ? Border.all(
                 color: const Color(0xFFE5EAF0),
               )
             : null,
         boxShadow: [
           BoxShadow(
             color: Colors.black.withValues(alpha: 0.06),
             blurRadius: 18,
             offset: const Offset(0, 8),
           ),
         ],
       );
     }


     class _KmlPolygonZoneDraft {
       final String name;
       final PolygonZoneType type;

       const _KmlPolygonZoneDraft({
         required this.name,
         required this.type,
       });
     }

     class MapPage extends StatefulWidget {
       /// Set when opening the map directly from the herd page.
       final String? initialRouteTagId;

       const MapPage({super.key, this.initialRouteTagId});

       @override
       State<MapPage> createState() => MapPageState();
     }

     class MapPageState extends State<MapPage> {
       bool isLoading = true;
       List<TagRecord> records = [];
       List<AreaZone> zones = [];
       List<PolygonZone> polygonZones = [];

       Timer? mapRefreshTimer;
       Timer? mapRecordsReloadTimer;
       GeoArea? currentArea;
       bool _legacyOverallBounds = false;
       String _searchText = '';
       MapCamelFilter _filter = MapCamelFilter.all;
       String? _focusedTagId;
       bool _onlineMode = false;
       DateTime _selectedDay = RecordDayService.today;
       bool _followingToday = true;
       String _lastTodayKey = RecordDayService.todayKey;
       Map<String, String> _camelPhotoPaths = {};
       String? _routeTagId;
       List<TagRecord> _routeRecords = [];
       int _routeRequestVersion = 0;
       final GlobalKey _mapSectionKey = GlobalKey();
       final ScrollController _pageScrollController = ScrollController();
       bool _scrollToMapWhenReady = false;
       int _recordsRequestVersion = 0;
       Timer? _mapDataReloadTimer;

       void _onMapDataChanged() {
         _mapDataReloadTimer?.cancel();
         _mapDataReloadTimer = Timer(const Duration(milliseconds: 400), () {
           if (mounted) unawaited(_reloadMapData());
         });
       }

       String _dateLabel(DateTime day) {
         final today = RecordDayService.isToday(day);
         return '${JalaliDateUi.format(day)}${today ? ' • امروز' : ''}';
       }

       Future<void> _selectMapDay() async {
         final today = RecordDayService.today;
         final selected = await JalaliDateUi.pick(
           context,
           initialDate: _selectedDay,
           firstDate: RecordDayService.oldestDay,
           lastDate: today,
           helpText: 'روز نمایش موقعیت‌ها و مسیر شتر',
           confirmText: 'نمایش',
         );
         if (!mounted || selected == null) return;
         _selectedDay = selected;
         _followingToday = RecordDayService.isToday(selected);
         ++_routeRequestVersion;
         setState(() { records = []; _routeRecords = []; });
         await loadRecords();
         if (_routeTagId != null) {
           final request = ++_routeRequestVersion;
           unawaited(_loadCamelRoute(_routeTagId!, request));
         }
       }

       Future<void> _toggleCamelRoute(TagRecord record) async {
         if (_routeTagId == record.tagId) {
           ++_routeRequestVersion;
           setState(() { _routeTagId = null; _routeRecords = []; });
           return;
         }
         final request = ++_routeRequestVersion;
         setState(() { _routeTagId = record.tagId; _focusedTagId = record.tagId;
           _routeRecords = []; });
         await _loadCamelRoute(record.tagId, request);
       }

       Future<void> _loadCamelRoute(String tagId, int request) async {
         try {
           final track = await LocalStorageService.loadGpsTrackForTag(tagId, day: _selectedDay);
           if (!mounted || request != _routeRequestVersion || _routeTagId != tagId) return;
           setState(() => _routeRecords = track);
           if (track.isEmpty) showMapMessage('برای این شتر مسیر GPS ذخیره نشده است.');
         } catch (_) {
           if (!mounted || request != _routeRequestVersion) return;
           showMapMessage('خواندن مسیر شتر ممکن نشد.', isError: true);
         }
       }

       /// Public entry point used by the shell's existing map tab.
       /// Does not change the selected day; the user can pick any retained day.
       void showCamelRoute(String tagId) {
         if (!mounted || tagId.trim().isEmpty) return;
         final request = ++_routeRequestVersion;
         setState(() {
           _routeTagId = tagId;
           _focusedTagId = tagId;
           _routeRecords = [];
           _filter = MapCamelFilter.all;
           _searchText = '';
           _searchController.clear();
           _scrollToMapWhenReady = true;
         });
         unawaited(_loadCamelRoute(tagId, request));
         _scrollToMapIfReady();
       }

       void _scrollToMapIfReady() {
         WidgetsBinding.instance.addPostFrameCallback((_) {
           if (!mounted || !_scrollToMapWhenReady) return;
           final mapContext = _mapSectionKey.currentContext;
           if (mapContext != null) {
             _scrollToMapWhenReady = false;
             unawaited(Scrollable.ensureVisible(
               mapContext,
               duration: const Duration(milliseconds: 380),
               curve: Curves.easeOutCubic,
               alignment: 0.05,
             ));
             return;
           }
           // A ListView may not have built its off-screen map section yet.
           // Move toward it in bounded steps until its context is available.
           if (!_pageScrollController.hasClients) return;
           final position = _pageScrollController.position;
           final next = (position.pixels + 430.0)
               .clamp(0.0, position.maxScrollExtent).toDouble();
           if (next <= position.pixels + 1) return;
           unawaited(_pageScrollController.animateTo(
             next,
             duration: const Duration(milliseconds: 260),
             curve: Curves.easeOutCubic,
           ).then((_) {
             if (mounted && _scrollToMapWhenReady) _scrollToMapIfReady();
           }));
         });
       }

       final TextEditingController _searchController = TextEditingController();
       final ScrollController _camelListController = ScrollController();

       void _resetCamelListPosition() {
         WidgetsBinding.instance.addPostFrameCallback((_) {
           if (mounted && _camelListController.hasClients) {
             _camelListController.jumpTo(0);
           }
         });
       }

       void _onRecordsChanged() {
         if (mapRecordsReloadTimer?.isActive == true) return;
         mapRecordsReloadTimer = Timer(const Duration(seconds: 1), () {
           if (mounted) unawaited(loadRecords());
         });
       }

       @override
       void initState() {
         super.initState();

         if (widget.initialRouteTagId != null &&
             widget.initialRouteTagId!.trim().isNotEmpty) {
           _routeTagId = widget.initialRouteTagId;
           _focusedTagId = widget.initialRouteTagId;
           _scrollToMapWhenReady = true;
         }
         TagRecordsEvents.revision.addListener(_onRecordsChanged);
         MapDataEvents.revision.addListener(_onMapDataChanged);
         loadRecords(refreshPhotos: true);
         loadCurrentArea();
         loadPolygonZones();

         mapRefreshTimer = Timer.periodic(
           const Duration(seconds: 15),
           (_) {
             if (!mounted) return;
             if (_lastTodayKey != RecordDayService.todayKey) {
               _lastTodayKey = RecordDayService.todayKey;
               if (_followingToday) {
                 _selectedDay = RecordDayService.today;
                 unawaited(loadRecords());
               }
             }
             setState(() {});
           },
         );
       }

       @override
       void dispose() {
         TagRecordsEvents.revision.removeListener(_onRecordsChanged);
         MapDataEvents.revision.removeListener(_onMapDataChanged);
         _mapDataReloadTimer?.cancel();
         mapRecordsReloadTimer?.cancel();
         mapRefreshTimer?.cancel();
         _searchController.dispose();
         _camelListController.dispose();
         _pageScrollController.dispose();
         super.dispose();
       }

     Future<void> loadCurrentArea() async {
       final savedArea = await CurrentGeoAreaService.load();

       final defaultAreas = GeoAreaService.getAll();

       final area = savedArea ??
           (defaultAreas.isNotEmpty ? defaultAreas.first : null);

       if (!mounted) return;

       setState(() {
         currentArea = area;
         _legacyOverallBounds = savedArea != null;
       });
     }


     Future<void> resetCurrentAreaBoundsToDefault() async {
       final area = currentArea;

       if (area == null) {
         showMapMessage(
           'محدوده کلی فعالی وجود ندارد.',
           isError: true,
         );
         return;
       }

       final accepted = await showDialog<bool>(
         context: context,
         builder: (context) {
           return Directionality(
             textDirection: TextDirection.rtl,
             child: AlertDialog(
               title: const Text('حذف محدوده کلی'),
               content: Text(
                 'مرز KML محدوده «${area.name}» حذف شود و محدوده به مقدار پیش‌فرض برگردد؟',
               ),
               actions: [
                 TextButton(
                   onPressed: () {
                     Navigator.pop(context, false);
                   },
                   child: const Text('لغو'),
                 ),
                 ElevatedButton(
                   onPressed: () {
                     Navigator.pop(context, true);
                   },
                   style: ElevatedButton.styleFrom(
                     backgroundColor: Colors.red,
                     foregroundColor: Colors.white,
                   ),
                   child: const Text('حذف'),
                 ),
               ],
             ),
           );
         },
       );

       if (accepted != true) {
         return;
       }

       final existing = await PolygonZoneService.loadZones();
       await PolygonZoneService.saveZones(existing.where((zone) =>
           !zone.id.startsWith(MapHerdStatus.overallKmlIdPrefix)).toList());
       await loadPolygonZones();
       GeoArea? defaultArea;

       for (final item in GeoAreaService.getAll()) {
         if (item.id == area.id) {
           defaultArea = item;
           break;
         }
       }

       if (defaultArea == null) {
         await CurrentGeoAreaService.clear();

         if (!mounted) return;

         setState(() {
           currentArea = null;
           _legacyOverallBounds = false;
         });

         showMapMessage('محدوده کلی حذف شد.');
         return;
       }

       await CurrentGeoAreaService.save(defaultArea);

       if (!mounted) return;

       setState(() {
         currentArea = defaultArea;
         _legacyOverallBounds = false;
       });

       showMapMessage(
         'محدوده کلی به حالت پیش‌فرض برگشت.',
       );
     }


     Future<void> loadPolygonZones() async {
       final loadedZones =
           await PolygonZoneService.loadActiveZones();

       if (!mounted) return;

       setState(() {
         polygonZones = loadedZones;
       });
     }



     Future<void> openPolygonZoneForm() async {
       if (currentArea == null) {
         ScaffoldMessenger.of(context).showSnackBar(
           const SnackBar(
             content: Text(
               'ابتدا محدوده کلی فعال را انتخاب کنید.',
               textDirection: TextDirection.rtl,
             ),
           ),
         );

         return;
       }

       final result = await Navigator.of(context).push<bool>(
         MaterialPageRoute(
           builder: (_) => const PolygonZoneFormPage(),
         ),
       );

       if (result == true) {
         await loadPolygonZones();
       }
     }





     Future<void> importKmlForCurrentArea() async {
       final area = currentArea;

       if (area == null) {
         ScaffoldMessenger.of(context).showSnackBar(
           const SnackBar(
             content: Text(
               'ابتدا محدوده کلی فعال را انتخاب کنید.',
               textDirection: TextDirection.rtl,
             ),
           ),
         );

         return;
       }

       try {
      final pickedResult = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: [
          'kml',
        ],
        allowMultiple: false,
      );

      if (pickedResult == null || pickedResult.files.isEmpty) {
        return;
      }

      final path = pickedResult.files.single.path;


         if (path == null || path.trim().isEmpty) {
           showMapMessage(
             'مسیر فایل KML دریافت نشد.',
             isError: true,
           );
           return;
         }

         final result =
             await KmlImportService.parseKmlFile(path);

         if (!result.isValid) {
           showMapMessage(
             'داخل فایل KML چندضلعی معتبر پیدا نشد. فایل باید حداقل ۳ نقطه داشته باشد.',
             isError: true,
           );
           return;
         }

         if (!mounted) return;

         final accepted =
             await showKmlImportConfirmDialog(result);

         if (accepted != true) {
           return;
         }

         final updatedArea =
             KmlImportService.applyResultToArea(
           area: area,
           result: result,
         );

         await CurrentGeoAreaService.save(updatedArea);
         // Unlike the legacy bounds-only storage, save the actual KML rings
         // as named polygons. Same persistent store as manually drawn fences.
         final existing = await PolygonZoneService.loadZones();
         final now = DateTime.now();
         final imported = <PolygonZone>[
           for (var i = 0; i < result.features.length; i++)
             PolygonZone(
               id: '${MapHerdStatus.overallKmlIdPrefix}${area.id}-$i',
               name: result.features.length == 1
                   ? result.name : result.features[i].name,
               type: PolygonZoneType.grazing,
               points: result.features[i].points,
               holes: result.features[i].holes,
               isActive: true,
               createdAt: now,
               updatedAt: now,
             ),
         ];
         await PolygonZoneService.saveZones([
           ...existing.where((zone) =>
               !zone.id.startsWith(MapHerdStatus.overallKmlIdPrefix)),
           ...imported,
         ]);
         await loadPolygonZones();

         if (!mounted) return;

         setState(() {
           currentArea = updatedArea;
           _legacyOverallBounds = false;
         });

         showMapMessage(
           'محدوده کلی ${area.name} از فایل KML به‌روزرسانی شد.',
         );
       } catch (e) {
         showMapMessage(
           'خطا در خواندن فایل KML: $e',
           isError: true,
         );
       }
     }


     String polygonZoneTypeLabelForPage(
       PolygonZoneType type,
     ) {
       switch (type) {
         case PolygonZoneType.grazing:
           return 'چراگاه';

         case PolygonZoneType.barn:
           return 'آغل';

         case PolygonZoneType.forbidden:
           return 'محدوده ممنوع';

         case PolygonZoneType.water:
           return 'آبشخور';

         case PolygonZoneType.custom:
           return 'سفارشی';
       }
     }

     Color polygonZoneTypeColorForPage(
       PolygonZoneType type,
     ) {
       switch (type) {
         case PolygonZoneType.grazing:
           return const Color(0xFF008B62);

         case PolygonZoneType.barn:
           return const Color(0xFF795548);

         case PolygonZoneType.forbidden:
           return const Color(0xFFD32F2F);

         case PolygonZoneType.water:
           return const Color(0xFF086EBB);

         case PolygonZoneType.custom:
           return const Color(0xFF6A1B9A);
       }
     }

     bool isPointInsideCurrentArea(
       GeoPoint point,
     ) {
       final area = currentArea;

       if (area == null) {
         return true;
       }

       return point.latitude >= area.southLatitude &&
           point.latitude <= area.northLatitude &&
           point.longitude >= area.westLongitude &&
           point.longitude <= area.eastLongitude;
     }

     int countPointsOutsideCurrentArea(
       List<GeoPoint> points,
     ) {
       int count = 0;

       for (final point in points) {
         if (!isPointInsideCurrentArea(point)) {
           count++;
         }
       }

       return count;
     }



     Future<bool?> showKmlImportConfirmDialog(
       KmlImportResult result,
     ) {
       return showDialog<bool>(
         context: context,
         builder: (context) {
           return Directionality(
             textDirection: TextDirection.rtl,
             child: AlertDialog(
               title: const Text(
                 'تایید وارد کردن KML',
               ),
               content: Column(
                 mainAxisSize: MainAxisSize.min,
                 crossAxisAlignment:
                     CrossAxisAlignment.start,
                 children: [
                   Text(
                     'نام فایل: ${result.fileName}',
                   ),

                   const SizedBox(height: 8),

                   Text(
                     'نام محدوده داخل KML: ${result.name}',
                   ),

                   const SizedBox(height: 8),

                   Text(
                     'تعداد نقاط: ${result.points.length}',
                   ),

                   const SizedBox(height: 12),

                   Text(
                     'شمال: ${result.northLatitude.toStringAsFixed(6)}',
                     textDirection: TextDirection.ltr,
                   ),

                   Text(
                     'جنوب: ${result.southLatitude.toStringAsFixed(6)}',
                     textDirection: TextDirection.ltr,
                   ),

                   Text(
                     'شرق: ${result.eastLongitude.toStringAsFixed(6)}',
                     textDirection: TextDirection.ltr,
                   ),

                   Text(
                     'غرب: ${result.westLongitude.toStringAsFixed(6)}',
                     textDirection: TextDirection.ltr,
                   ),

                   const SizedBox(height: 12),

                   const Text(
                     'این فایل، محدوده کلی فعال را به‌روزرسانی می‌کند.',
                     style: TextStyle(
                       color: Colors.black54,
                     ),
                   ),
                 ],
               ),
               actions: [
                 TextButton(
                   onPressed: () {
                     Navigator.pop(context, false);
                   },
                   child: const Text(
                     'لغو',
                   ),
                 ),

                 ElevatedButton(
                   onPressed: () {
                     Navigator.pop(context, true);
                   },
                   child: const Text(
                     'تایید و ذخیره',
                   ),
                 ),
               ],
             ),
           );
         },
       );
     }

     void showMapMessage(
       String message, {
       bool isError = false,
     }) {
       ScaffoldMessenger.of(context).showSnackBar(
         SnackBar(
           content: Text(
             message,
             textDirection: TextDirection.rtl,
           ),
           backgroundColor:
               isError ? Colors.red : const Color(0xFF008B62),
         ),
       );
     }



     Future<void> importKmlAsInternalPolygonZone() async {
       if (currentArea == null) {
         showMapMessage(
           'ابتدا محدوده کلی فعال را انتخاب کنید.',
           isError: true,
         );
         return;
       }

       try {
         final pickedResult =
             await FilePicker.platform.pickFiles(
           type: FileType.custom,
           allowedExtensions: [
             'kml',
           ],
           allowMultiple: false,
           withData: true,
         );

         if (pickedResult == null ||
             pickedResult.files.isEmpty) {
           return;
         }

         final selectedFile =
             pickedResult.files.single;

         KmlImportResult result;

         final path =
             selectedFile.path;

         if (path != null && path.trim().isNotEmpty) {
           result =
               await KmlImportService.parseKmlFile(path);
         } else if (selectedFile.bytes != null) {
           result = KmlImportService.parseKmlText(
             utf8.decode(selectedFile.bytes!),
             fileName: selectedFile.name,
           );
         } else {
           showMapMessage(
             'فایل KML قابل خواندن نیست.',
             isError: true,
           );
           return;
         }

         if (!result.isValid) {
           showMapMessage(
             'داخل فایل KML چندضلعی معتبر پیدا نشد.',
             isError: true,
           );
           return;
         }

         if (!mounted) return;

         final draft =
             await showKmlPolygonZoneDialog(result);

         if (draft == null) {
           return;
         }

         final outsideCount =
             result.features.fold<int>(0, (sum, feature) =>
                 sum + countPointsOutsideCurrentArea(feature.points));

         if (outsideCount > 0) {
           final accepted =
               await showDialog<bool>(
             context: context,
             builder: (context) {
               return Directionality(
                 textDirection: TextDirection.rtl,
                 child: AlertDialog(
                   title: const Text(
                     'بخشی از محدوده خارج از محدوده کلی است',
                   ),
                   content: Text(
                     '$outsideCount نقطه از این KML خارج از محدوده کلی فعال قرار دارد. آیا باز هم ذخیره شود؟',
                   ),
                   actions: [
                     TextButton(
                       onPressed: () {
                         Navigator.pop(context, false);
                       },
                       child: const Text('لغو'),
                     ),
                     ElevatedButton(
                       onPressed: () {
                         Navigator.pop(context, true);
                       },
                       child: const Text('ذخیره شود'),
                     ),
                   ],
                 ),
               );
             },
           );

           if (accepted != true) {
             return;
           }
         }

         final now = DateTime.now();

         final existing = await PolygonZoneService.loadZones();
         final imported = <PolygonZone>[
           for (var i = 0; i < result.features.length; i++)
             PolygonZone(
               id: '${PolygonZoneService.createId()}-$i',
               name: result.features.length == 1
                   ? draft.name : '${draft.name} / ${result.features[i].name}',
               type: draft.type,
               points: result.features[i].points,
               holes: result.features[i].holes,
               isActive: true,
               createdAt: now,
               updatedAt: now,
             ),
         ];
         await PolygonZoneService.saveZones([...existing, ...imported]);
         await loadPolygonZones();
         showMapMessage('${imported.length} محدوده از KML ثبت شد.');
       } catch (e) {
         showMapMessage(
           'خطا در وارد کردن KML داخلی: $e',
           isError: true,
         );
       }
     }





     Future<_KmlPolygonZoneDraft?> showKmlPolygonZoneDialog(
       KmlImportResult result,
     ) async {
       final nameController = TextEditingController(
         text: result.name,
       );

       PolygonZoneType selectedType =
           PolygonZoneType.grazing;

       final dialogResult =
           await showDialog<_KmlPolygonZoneDraft>(
         context: context,
         builder: (context) {
           return Directionality(
             textDirection: TextDirection.rtl,
             child: StatefulBuilder(
               builder: (context, setDialogState) {
                 return AlertDialog(
                   title: const Text(
                     'وارد کردن محدوده داخلی',
                   ),
                   content: SingleChildScrollView(
                     child: Column(
                       mainAxisSize: MainAxisSize.min,
                       crossAxisAlignment:
                           CrossAxisAlignment.start,
                       children: [
                         Text(
                           'نام فایل: ${result.fileName}',
                         ),

                         const SizedBox(height: 8),

                         Text(
                           'تعداد نقاط: ${result.points.length}',
                         ),

                         const SizedBox(height: 12),

                         TextField(
                           controller: nameController,
                           decoration: const InputDecoration(
                             labelText: 'نام محدوده',
                             hintText: 'مثلاً چراگاه شمالی',
                           ),
                         ),

                         const SizedBox(height: 12),

                         DropdownButtonFormField<PolygonZoneType>(
                           value: selectedType,
                           decoration: const InputDecoration(
                             labelText: 'نوع محدوده',
                           ),
                           items: PolygonZoneType.values.map(
                             (type) {
                               return DropdownMenuItem(
                                 value: type,
                                 child: Text(
                                   polygonZoneTypeLabelForPage(type),
                                 ),
                               );
                             },
                           ).toList(),
                           onChanged: (value) {
                             if (value == null) return;

                             setDialogState(() {
                               selectedType = value;
                             });
                           },
                         ),

                         const SizedBox(height: 12),

                         Text(
                           'شمال: ${result.northLatitude.toStringAsFixed(6)}',
                           textDirection: TextDirection.ltr,
                         ),

                         Text(
                           'جنوب: ${result.southLatitude.toStringAsFixed(6)}',
                           textDirection: TextDirection.ltr,
                         ),

                         Text(
                           'شرق: ${result.eastLongitude.toStringAsFixed(6)}',
                           textDirection: TextDirection.ltr,
                         ),

                         Text(
                           'غرب: ${result.westLongitude.toStringAsFixed(6)}',
                           textDirection: TextDirection.ltr,
                         ),
                       ],
                     ),
                   ),
                   actions: [
                     TextButton(
                       onPressed: () {
                         Navigator.pop(context);
                       },
                       child: const Text('لغو'),
                     ),

                     ElevatedButton(
                       onPressed: () {
                         final name =
                             nameController.text.trim();

                         if (name.isEmpty) {
                           return;
                         }

                         Navigator.pop(
                           context,
                           _KmlPolygonZoneDraft(
                             name: name,
                             type: selectedType,
                           ),
                         );
                       },
                       child: const Text(
                         'ذخیره محدوده داخلی',
                       ),
                     ),
                   ],
                 );
               },
             ),
           );
         },
       );

       nameController.dispose();

       return dialogResult;
     }





     Future<void> deletePolygonZone(
       PolygonZone zone,
     ) async {
       final accepted =
           await showDialog<bool>(
         context: context,
         builder: (context) {
           return Directionality(
             textDirection: TextDirection.rtl,
             child: AlertDialog(
               title: const Text(
                 'حذف محدوده',
               ),
               content: Text(
                 'محدوده «${zone.name}» حذف شود؟',
               ),
               actions: [
                 TextButton(
                   onPressed: () {
                     Navigator.pop(context, false);
                   },
                   child: const Text('لغو'),
                 ),
                 ElevatedButton(
                   onPressed: () {
                     Navigator.pop(context, true);
                   },
                   style: ElevatedButton.styleFrom(
                     backgroundColor: Colors.red,
                     foregroundColor: Colors.white,
                   ),
                   child: const Text('حذف'),
                 ),
               ],
             ),
           );
         },
       );

       if (accepted != true) {
         return;
       }

       await PolygonZoneService.deleteZone(zone.id);

       await loadPolygonZones();

       showMapMessage(
         'محدوده حذف شد.',
       );
     }


     Widget buildPolygonZoneListItem(
       PolygonZone zone,
     ) {
       final color =
           polygonZoneTypeColorForPage(zone.type);

       return Container(
         margin: const EdgeInsets.only(top: 10),
         padding: const EdgeInsets.all(12),
         decoration: BoxDecoration(
           color: color.withValues(alpha: 0.06),
           borderRadius: BorderRadius.circular(14),
           border: Border.all(
             color: color.withValues(alpha: 0.25),
           ),
         ),
         child: Row(
           children: [
             Icon(
               Icons.polyline_rounded,
               color: color,
             ),

             const SizedBox(width: 10),

             Expanded(
               child: Column(
                 crossAxisAlignment:
                     CrossAxisAlignment.start,
                 children: [
                   Text(
                     zone.name,
                     style: const TextStyle(
                       fontWeight: FontWeight.bold,
                     ),
                   ),

                   const SizedBox(height: 3),

                   Text(
                     '${polygonZoneTypeLabelForPage(zone.type)} / ${zone.points.length} نقطه',
                     style: const TextStyle(
                       color: Colors.black54,
                       fontSize: 12,
                     ),
                   ),
                 ],
               ),
             ),

             IconButton(
               onPressed: () {
                 deletePolygonZone(zone);
               },
               icon: const Icon(
                 Icons.delete_rounded,
                 color: Colors.red,
               ),
             ),
           ],
         ),
       );
     }


     Widget buildPolygonZoneToolsCard() {
       return Container(
         padding: const EdgeInsets.all(14),
         decoration: _mapCardDecoration(),
         child: Column(
           crossAxisAlignment: CrossAxisAlignment.start,
           children: [
             Row(
               children: [
                 const Icon(
                   Icons.polyline_rounded,
                   color: Color(0xFF086EBB),
                 ),

                 const SizedBox(width: 8),

                 Expanded(
                   child: Text(
                     'محدوده‌های داخلی: ${polygonZones.length}',
                     style: const TextStyle(
                       fontWeight: FontWeight.bold,
                     ),
                   ),
                 ),
               ],
             ),

             const SizedBox(height: 12),

             SizedBox(
               width: double.infinity,
               height: 48,
               child: ElevatedButton.icon(
                 onPressed: openPolygonZoneForm,
                 icon: const Icon(
                   Icons.add_location_alt_rounded,
                 ),
                 label: const Text(
                   'تعریف محدوده داخلی با GPS',
                 ),
               ),
             ),

             const SizedBox(height: 10),

             SizedBox(
               width: double.infinity,
               height: 48,
               child: OutlinedButton.icon(
                 onPressed: importKmlAsInternalPolygonZone,
                 icon: const Icon(
                   Icons.upload_file_rounded,
                 ),
                 label: const Text(
                   'وارد کردن KML به عنوان محدوده داخلی',
                 ),
               ),
             ),

             const SizedBox(height: 10),

             SizedBox(
               width: double.infinity,
               height: 48,
               child: OutlinedButton.icon(
                 onPressed: importKmlForCurrentArea,
                 icon: const Icon(
                   Icons.public_rounded,
                 ),
                 label: const Text(
                   'وارد کردن KML برای محدوده کلی فعال',
                 ),
               ),
             ),
             const SizedBox(height: 10),

             SizedBox(
               width: double.infinity,
               height: 48,
               child: OutlinedButton.icon(
                 onPressed: resetCurrentAreaBoundsToDefault,
                 icon: const Icon(
                   Icons.delete_outline_rounded,
                   color: Colors.red,
                 ),
                 label: const Text(
                   'حذف محدوده کلی واردشده با KML',
                   style: TextStyle(
                     color: Colors.red,
                   ),
                 ),
               ),
             ),

             if (polygonZones.isEmpty) ...[
               const SizedBox(height: 12),

               Container(
                 width: double.infinity,
                 padding: const EdgeInsets.all(12),
                 decoration: BoxDecoration(
                   color: const Color(0xFFF5F7FA),
                   borderRadius: BorderRadius.circular(14),
                 ),
                 child: const Text(
                   'هنوز محدوده داخلی ثبت نشده است.',
                   textAlign: TextAlign.center,
                   style: TextStyle(
                     color: Colors.black54,
                   ),
                 ),
               ),
             ] else ...[
               const SizedBox(height: 12),

               ...polygonZones.map(
                 buildPolygonZoneListItem,
               ),
             ],
           ],
         ),
       );
     }

       Future<void> loadRecords({bool refreshPhotos = false}) async {
         final request = ++_recordsRequestVersion;
         final loadedRecords = await LocalStorageService.loadMapCamels(day: _selectedDay);
         final loadedZones = await AreaZoneService.loadZones();
         Map<String, String> newPhotos = _camelPhotoPaths;
         if (refreshPhotos || isLoading) {
           try {
             final details = await CamelDetailService.loadAllDetails(limit: 10000);
             newPhotos = {
               for (final detail in details)
                 if (detail.photoPath.trim().isNotEmpty)
                   detail.tagId: detail.photoPath,
             };
           } catch (_) {
             // GPS can remain usable without the optional profile database.
           }
         }

         if (!mounted || request != _recordsRequestVersion) return;

         setState(() {
           _camelPhotoPaths = newPhotos;
           records = loadedRecords;
           zones = loadedZones;
           isLoading = false;
         });
         if (_routeTagId != null && _followingToday) {
           final routeRequest = ++_routeRequestVersion;
           unawaited(_loadCamelRoute(_routeTagId!, routeRequest));
         }
         if (_scrollToMapWhenReady) _scrollToMapIfReady();
       }

       bool hasGps(TagRecord record) {
         final lat = record.latitude;
         final lon = record.longitude;
         return lat != null && lon != null && lat.isFinite && lon.isFinite &&
             lat.abs() <= 90 && lon.abs() <= 180 && !(lat == 0 && lon == 0);
       }

       DateTime? recordDateTime(TagRecord record) {
         final text = record.receivedDateTime.trim();

         if (text.isEmpty) return null;

         return IranTime.parseForDisplay(text);
       }

       bool isSameDay(DateTime a, DateTime b) {
         return a.year == b.year && a.month == b.month && a.day == b.day;
       }

       List<TagRecord> getTodayRecords(List<TagRecord> source) {
         final now = IranTime.nowWallClock();

         return source.where((record) {
           final parsed = recordDateTime(record);

           if (parsed == null) return false;

           return isSameDay(parsed, now);
         }).toList();
       }

       /// Historic positions remain visible even when no GPS was captured
       /// today. Mark them as historical; do not represent as live positions.
       List<TagRecord> get gpsRecords {
         return records.where(hasGps).toList();
       }

       List<TagRecord> get latestGpsRecordsByTag {
         final result = <TagRecord>[];
         final seenTags = <String>{};

         for (final record in gpsRecords) {
           if (seenTags.contains(record.tagId)) continue;

           seenTags.add(record.tagId);
           result.add(record);
         }

         return result;
       }

       String twoDigit(int value) {
         return value.toString().padLeft(2, '0');
       }

       String recordDateText(TagRecord record) {
         final date = IranTime.parseForDisplay(record.receivedDateTime);

         if (date == null) {
           return record.receivedTime;
         }

         return JalaliDateUi.dateTime(date);
       }




       Future<void> _reloadMapData() async {
         await Future.wait([
           loadRecords(refreshPhotos: true),
           loadCurrentArea(),
           loadPolygonZones(),
         ]);
       }

       String _camelDisplayName(TagRecord record) {
         final name = record.camelName.trim();
         if (name.isNotEmpty && name != 'شتر ثبت‌نشده' &&
             name != 'شتر ثبت نشده' && name != '-') {
           return name;
         }
         return 'شتر شماره ${record.camelNo}';
       }

       String _normalizeSearch(String input) {
         const sourceDigits = '۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩';
         const asciiDigits = '01234567890123456789';
         var text = input.trim().toLowerCase()
             .replaceAll('ي', 'ی').replaceAll('ك', 'ک');
         for (var i = 0; i < sourceDigits.length; i++) {
           text = text.replaceAll(sourceDigits[i], asciiDigits[i]);
         }
         return text;
       }

       bool _searchMatches(TagRecord record) {
         final query = _normalizeSearch(_searchText);
         if (query.isEmpty) return true;
         return _normalizeSearch(record.camelName).contains(query) ||
             _normalizeSearch(record.camelNo).contains(query) ||
             _normalizeSearch(record.tagId).contains(query) ||
             _normalizeSearch(_camelDisplayName(record)).contains(query);
       }

       Future<void> _openInExternalMap() async {
         TagRecord? selected;
         for (final record in latestGpsRecordsByTag) {
           if (record.tagId == _focusedTagId) {
             selected = record;
             break;
           }
         }
         if (selected == null && latestGpsRecordsByTag.isNotEmpty) {
           selected = latestGpsRecordsByTag.first;
         }
         final lat = selected?.latitude ?? currentArea?.centerLatitude;
         final lon = selected?.longitude ?? currentArea?.centerLongitude;
         if (lat == null || lon == null) return;
         final url = Uri.https('www.google.com', '/maps/search/', {
           'api': '1', 'query': '$lat,$lon',
         });
         final opened = await launchUrl(url, mode: LaunchMode.externalApplication);
         if (!opened && mounted) {
           showMapMessage('برنامه نقشه دیگری در دسترس نیست.', isError: true);
         }
       }

       Widget _zoneTools() {
         final actions = <MapZoneActionData>[
           MapZoneActionData('KML داخلی', Icons.file_upload_outlined,
               const Color(0xFF167E62), importKmlAsInternalPolygonZone),
           MapZoneActionData('KML کلی', Icons.public_rounded,
               const Color(0xFF2B78B9), importKmlForCurrentArea),
           MapZoneActionData('محدوده دستی', Icons.add_location_alt_outlined,
               const Color(0xFF7257AB), openPolygonZoneForm),
           MapZoneActionData('حذف محدوده کلی', Icons.delete_outline_rounded,
               const Color(0xFFC84F4B), resetCurrentAreaBoundsToDefault),
         ];
         return Column(
           crossAxisAlignment: CrossAxisAlignment.start,
           children: [
             const MapSectionTitle('ابزارهای محدوده'),
             const SizedBox(height: 10),
             SizedBox(
               height: 108,
               child: ListView.separated(
                 scrollDirection: Axis.horizontal,
                 itemCount: actions.length,
                 separatorBuilder: (_, __) => const SizedBox(width: 9),
                 itemBuilder: (context, index) => MapZoneActionCard(
                   data: actions[index],
                   onCompleted: _reloadMapData,
                 ),
               ),
             ),
             if (polygonZones.isNotEmpty) ...[
               const SizedBox(height: 8),
               TextButton.icon(
                 onPressed: () => showModalBottomSheet<void>(
                   context: context,
                   isScrollControlled: true,
                   showDragHandle: true,
                   builder: (sheetContext) => SafeArea(
                     child: Padding(
                       padding: const EdgeInsets.all(16),
                       child: Column(
                         mainAxisSize: MainAxisSize.min,
                         children: [
                           const Text('محدوده‌های داخلی ثبت‌شده',
                               style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                           const SizedBox(height: 8),
                           Flexible(
                             child: ListView(
                               shrinkWrap: true,
                               children: polygonZones.map((zone) => ListTile(
                                 title: Text(zone.name),
                                 subtitle: Text('${zone.points.length} نقطه'),
                                 trailing: IconButton(
                                   tooltip: 'حذف محدوده',
                                   icon: const Icon(Icons.delete_outline_rounded),
                                   onPressed: () async {
                                     Navigator.pop(sheetContext);
                                     await deletePolygonZone(zone);
                                     await _reloadMapData();
                                   },
                                 ),
                               )).toList(),
                             ),
                           ),
                         ],
                       ),
                     ),
                   ),
                 ),
                 icon: const Icon(Icons.layers_outlined, size: 18),
                 label: Text('محدوده‌های داخلی (${polygonZones.length})'),
               ),
             ],
           ],
         );
       }

       @override
       Widget build(BuildContext context) {
         final allCamels = latestGpsRecordsByTag;
         final activeZones = zones.where((zone) => zone.isActive).toList();
         final activePolygons = polygonZones
             .where((zone) => zone.isActive && zone.isValid).toList();
         final assessmentByTag = {
           for (final camel in allCamels)
             camel.tagId: MapHerdStatus.assess(
               camel, currentArea, activeZones, activePolygons,
               useLegacyOverallBounds: _legacyOverallBounds,
             ),
         };
         final statusByTag = {
           for (final entry in assessmentByTag.entries)
             entry.key: entry.value.state,
         };
         final lowBatteryCount = allCamels.where((c) => c.isBatteryLow).length;
         final outsideCount = allCamels.where(
           (c) => statusByTag[c.tagId] == MapBoundaryState.outside,
         ).length;
         final matched = allCamels.where((camel) {
           if (!_searchMatches(camel)) return false;
           switch (_filter) {
             case MapCamelFilter.all:
               return true;
             case MapCamelFilter.inside:
               return statusByTag[camel.tagId] == MapBoundaryState.inside;
             case MapCamelFilter.outside:
               return statusByTag[camel.tagId] == MapBoundaryState.outside;
             case MapCamelFilter.lowBattery:
               return camel.isBatteryLow;
           }
         }).toList();
         // Keep marker set aligned with the very same search/filter as cards.
         final availableMapRecords = matched;
         final hasMapContent = allCamels.isNotEmpty || activeZones.isNotEmpty ||
             activePolygons.isNotEmpty || currentArea != null;

         return Directionality(
           textDirection: TextDirection.rtl,
           child: Scaffold(
             backgroundColor: const Color(0xFFFCF8F4),
             body: Column(
               children: [
                 MapWarmHeader(
                   onBack: widget.initialRouteTagId == null
                       ? null
                       : () => Navigator.of(context).maybePop(),
                 ),
                 Expanded(
                   child: isLoading
                     ? const Center(child: CircularProgressIndicator())
                     : RefreshIndicator(
                         onRefresh: _reloadMapData,
                         color: const Color(0xFFAF582F),
                         child: ListView(
                           controller: _pageScrollController,
                           physics: const AlwaysScrollableScrollPhysics(),
                           padding: const EdgeInsets.fromLTRB(14, 12, 14, 105),
                           children: [
                             const MapHeroBanner(),
                             const SizedBox(height: 10),
                             Container(
                               decoration: _mapCardDecoration(radius: 16),
                               child: ListTile(
                                 dense: true,
                                 leading: const Icon(Icons.event_rounded, color: Color(0xFFB65C2E)),
                                 title: Text('موقعیت و مسیر: ${_dateLabel(_selectedDay)}',
                                   style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                                 subtitle: const Text('امروز یا یکی از ۹ روز گذشته'),
                                 trailing: const Icon(Icons.expand_more_rounded),
                                 onTap: _selectMapDay,
                               ),
                             ),
                             const SizedBox(height: 12),
                             Row(children: [
                               Expanded(child: MapStatCard(
                                 label: 'روی نقشه', count: allCamels.length,
                                 icon: Icons.pets_rounded,
                                 tint: const Color(0xFFE9F6EE),
                                 foreground: const Color(0xFF147A54),
                               )),
                               const SizedBox(width: 8),
                               Expanded(child: MapStatCard(
                                 label: 'خارج محدوده', count: outsideCount,
                                 icon: Icons.report_problem_outlined,
                                 tint: const Color(0xFFFFEBED),
                                 foreground: const Color(0xFFC63F50),
                               )),
                               const SizedBox(width: 8),
                               Expanded(child: MapStatCard(
                                 label: 'باتری ضعیف', count: lowBatteryCount,
                                 icon: Icons.battery_alert_rounded,
                                 tint: const Color(0xFFFFF1E0),
                                 foreground: const Color(0xFFDB7E18),
                               )),
                             ]),
                             const SizedBox(height: 17),
                             _zoneTools(),
                             const SizedBox(height: 14),
                             MapSearchField(
                               controller: _searchController,
                               onChanged: (value) {
                                 setState(() => _searchText = value);
                                 _resetCamelListPosition();
                               },
                             ),
                             const SizedBox(height: 10),
                             MapFilterChips(
                               selected: _filter,
                               onSelected: (value) {
                                 setState(() => _filter = value);
                                 _resetCamelListPosition();
                               },
                             ),
                             const SizedBox(height: 11),
                             if (matched.isNotEmpty)
                               SizedBox(
                                 height: 98,
                                 child: ListView.separated(
                                   scrollDirection: Axis.horizontal,
                                   itemCount: matched.length,
                                   separatorBuilder: (_, __) => const SizedBox(width: 12),
                                   itemBuilder: (context, index) {
                                     final camel = matched[index];
                                     return MapCamelAvatar(
                                       name: _camelDisplayName(camel),
                                       photoPath: _camelPhotoPaths[camel.tagId],
                                       selected: _focusedTagId == camel.tagId,
                                       onTap: () => setState(() => _focusedTagId = camel.tagId),
                                     );
                                   },
                                 ),
                               )
                             else
                               const Padding(
                                 padding: EdgeInsets.all(12),
                                 child: Text('شتر مطابق جستجو یا فیلتر پیدا نشد.',
                                     textAlign: TextAlign.center),
                               ),
                             const SizedBox(height: 11),
                             Container(
                               key: _mapSectionKey,
                               decoration: _mapCardDecoration(radius: 20),
                               padding: const EdgeInsets.all(8),
                               child: Column(children: [
                                 Row(children: [
                                   const Expanded(child: Text('نمای موقعیت‌ها',
                                     style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14))),
                                   IconButton(
                                     tooltip: 'باز کردن موقعیت در برنامه نقشه دیگر',
                                     onPressed: _openInExternalMap,
                                     icon: const Icon(Icons.open_in_new_rounded,
                                       color: Color(0xFFB65C2E), size: 21),
                                   ),
                                   MapModeSwitch(
                                     online: _onlineMode,
                                     onChanged: (value) => setState(() => _onlineMode = value),
                                   ),
                                 ]),
                                 if (_routeTagId != null && allCamels.isNotEmpty)
                                   Padding(
                                     padding: const EdgeInsets.only(top: 5, bottom: 6),
                                     child: Row(children: [
                                       const Icon(Icons.route_rounded, size: 17,
                                         color: Color(0xFFB75C2D)),
                                       const SizedBox(width: 6),
                                       Expanded(child: Text(
                                         'مسیر ${_camelDisplayName(allCamels.firstWhere(
                                           (c) => c.tagId == _routeTagId,
                                           orElse: () => allCamels.first))} • ${_routeRecords.length} نقطه',
                                         maxLines: 1, overflow: TextOverflow.ellipsis,
                                         style: const TextStyle(fontSize: 11,
                                           fontWeight: FontWeight.bold))),
                                       IconButton(
                                         tooltip: 'بستن مسیر',
                                         onPressed: () {
                                           ++_routeRequestVersion;
                                           setState(() { _routeTagId = null; _routeRecords = []; });
                                         },
                                         icon: const Icon(Icons.close_rounded, size: 18)),
                                     ]),
                                   ),
                                 const SizedBox(height: 6),
                                 if (!hasMapContent)
                                   const SizedBox(
                                     height: 320,
                                     child: Center(child: Text('هنوز مختصات یا محدوده‌ای برای نمایش ثبت نشده است.')),
                                   )
                                 else if (_onlineMode)
                                   OnlineHerdMap(
                                     key: ValueKey('online-${RecordDayService.key(_selectedDay)}'),
                                     records: availableMapRecords,
                                     zones: activeZones,
                                     polygons: activePolygons,
                                     area: currentArea,
                                     selectedTagId: _focusedTagId,
                                     onCamelSelected: (record) => setState(() => _focusedTagId = record.tagId),
                                     nameForRecord: _camelDisplayName,
                                     routeRecords: _routeRecords,
                                   )
                                 else
                                   SimpleGpsMap(
                                     key: ValueKey('offline-${RecordDayService.key(_selectedDay)}'),
                                     records: availableMapRecords,
                                     trackRecords: _routeRecords,
                                     zones: activeZones,
                                     area: currentArea,
                                     polygonZones: activePolygons,
                                     drawAreaBounds: !activePolygons.any((zone) =>
                                         zone.id.startsWith(MapHerdStatus.overallKmlIdPrefix)),
                                     showQuickSelector: false,
                                     focusedTagId: _focusedTagId,
                                     routeTagId: _routeTagId,
                                     onRouteRequest: _toggleCamelRoute,
                                     onRouteClosed: () {
                                       ++_routeRequestVersion;
                                       setState(() { _routeTagId = null; _routeRecords = []; });
                                     },
                                     height: 355,
                                   ),
                                 const SizedBox(height: 6),
                                 const Padding(
                                   padding: EdgeInsets.symmetric(horizontal: 6),
                                   child: Text(
                                     'موقعیت‌ها فقط مربوط به روز انتخاب‌شده هستند و الزاماً زنده نیستند.',
                                     style: TextStyle(color: Colors.black54, fontSize: 10),
                                   ),
                                 ),
                               ]),
                             ),
                             const SizedBox(height: 18),
                             MapSectionTitle('شترهای روی نقشه (${matched.length})'),
                             const SizedBox(height: 10),
                             if (matched.isEmpty)
                               const Center(child: Text('موردی برای نمایش وجود ندارد.'))
                             else
                               LayoutBuilder(builder: (context, constraints) {
                                 final rowCount = (matched.length + 1) ~/ 2;
                                 final height = (rowCount * 160.0).clamp(165.0, 395.0).toDouble();
                                 return Container(
                                   height: height,
                                   decoration: _mapCardDecoration(radius: 18),
                                   padding: const EdgeInsets.all(7),
                                   child: Scrollbar(
                                     controller: _camelListController,
                                     thumbVisibility: rowCount > 2,
                                     child: ListView.builder(
                                       controller: _camelListController,
                                       key: const PageStorageKey('map_camel_list'),
                                       physics: const AlwaysScrollableScrollPhysics(),
                                       cacheExtent: 260,
                                       itemCount: rowCount,
                                       itemBuilder: (context, row) {
                                         final firstIndex = row * 2;
                                         final items = <TagRecord>[
                                           matched[firstIndex],
                                           if (firstIndex + 1 < matched.length) matched[firstIndex + 1],
                                         ];
                                         return Padding(
                                           padding: const EdgeInsets.only(bottom: 9),
                                           child: Row(
                                             crossAxisAlignment: CrossAxisAlignment.start,
                                             children: [
                                               for (var i = 0; i < 2; i++) ...[
                                                 if (i > 0) const SizedBox(width: 9),
                                                 Expanded(child: i >= items.length
                                                   ? const SizedBox.shrink()
                                                   : MapCompactCamelCard(
                                                     key: ValueKey(items[i].tagId),
                                                     record: items[i],
                                                     title: _camelDisplayName(items[i]),
                                                     photoPath: _camelPhotoPaths[items[i].tagId],
                                                     boundary: statusByTag[items[i].tagId] ?? MapBoundaryState.unknown,
                                                     zoneDescription: assessmentByTag[items[i].tagId]?.description ?? 'موقعیت نامشخص',
                                                     dateText: recordDateText(items[i]),
                                                     onShowOnMap: () => setState(() => _focusedTagId = items[i].tagId),
                                                     onRoute: () => _toggleCamelRoute(items[i]),
                                                     routeActive: _routeTagId == items[i].tagId,
                                                   )),
                                               ],
                                             ],
                                           ),
                                         );
                                       },
                                     ),
                                   ),
                                 );
                               }),
                           ],
                         ),
                       ),
                 ),
               ],
             ),
           ),
         );
       }
     }

     class MapSummaryCard extends StatelessWidget {
       final String title;
       final String value;
       final IconData icon;
       final Color color;

       const MapSummaryCard({
         super.key,
         required this.title,
         required this.value,
         required this.icon,
         required this.color,
       });

       @override
       Widget build(BuildContext context) {
         return Container(
           height: 104,
           padding: const EdgeInsets.all(10),
           decoration: _mapCardDecoration(),
           child: Column(
             mainAxisAlignment: MainAxisAlignment.center,
             children: [
               Icon(
                 icon,
                 color: color,
                 size: 26,
               ),
               const SizedBox(height: 7),
               Text(
                 value,
                 style: TextStyle(
                   color: color,
                   fontWeight: FontWeight.bold,
                   fontSize: 22,
                   height: 1,
                 ),
               ),
               const SizedBox(height: 7),
               Text(
                 title,
                 maxLines: 1,
                 overflow: TextOverflow.ellipsis,
                 style: const TextStyle(
                   color: Colors.black54,
                   fontSize: 12,
                   fontWeight: FontWeight.bold,
                 ),
               ),
             ],
           ),
         );
       }
     }



     enum MapDetailLevel {

       low,

       medium,

       high,

     }


   class CamelCluster {
     double latitude;
     double longitude;

     final String zoneKey;
     final String zoneTitle;

     final List<TagRecord> records;

     CamelCluster({
       required this.latitude,
       required this.longitude,
       required this.zoneKey,
       required this.zoneTitle,
       required this.records,
     });

     int get count {
       return records.length;
     }

     void addRecord(TagRecord record) {
       records.add(record);

       double latSum = 0;
       double lngSum = 0;

       for (final item in records) {
         latSum += item.latitude ?? 0;
         lngSum += item.longitude ?? 0;
       }

       latitude = latSum / records.length;
       longitude = lngSum / records.length;
     }
   }



  class SimpleGpsMap extends StatefulWidget {
    final List<TagRecord> records;
    final List<TagRecord> trackRecords;
    final List<AreaZone> zones;
    final GeoArea? area;
    final List<PolygonZone> polygonZones;
    final bool drawAreaBounds;
    final bool showQuickSelector;
    final String? focusedTagId;
    final String? routeTagId;
    final ValueChanged<TagRecord>? onRouteRequest;
    final VoidCallback? onRouteClosed;
    final double height;

      const SimpleGpsMap({
        super.key,
        required this.records,
        required this.trackRecords,
        this.zones = const [],
        this.area,
        this.polygonZones = const [],
        this.drawAreaBounds = true,
        this.showQuickSelector = true,
        this.focusedTagId,
        this.routeTagId,
        this.onRouteRequest,
        this.onRouteClosed,
        this.height = 450,
      });



       @override
       State<SimpleGpsMap> createState() => _SimpleGpsMapState();
     }

    class _SimpleGpsMapState
        extends State<SimpleGpsMap>
        with SingleTickerProviderStateMixin {
       static const double sceneWidth = 1200;
       static const double sceneHeight = 820;

       final TransformationController transformationController =
           TransformationController();

       TagRecord? selectedRecord;
       Size viewportSize = Size.zero;
       bool didFitInitialView = false;
       double currentMapScale = 1.0;
       bool showSelectedCamelPhoto = false;
       CamelDetail? selectedCamelDetail;
       bool isLoadingSelectedCamelDetail = false;
       String? selectedCamelPhotoError;
       TagRecord? routeRecord;
       List<TagRecord> routeRecords = [];
       List<CamelCluster>? _clusterCache;

       bool get isRouteMode {
         return routeRecord != null;
       }


       bool get showClusters {

         return currentMapScale < 1.5;

       }


       MapDetailLevel get currentDetailLevel {

         if (currentMapScale < 0.8) {
           return MapDetailLevel.low;
         }


         if (currentMapScale < 2.2) {
           return MapDetailLevel.medium;
         }


         return MapDetailLevel.high;
       }






       double markerSizeForRecord(TagRecord record) {

         return zoneScaleForRecord(record);

       }


double zoneScaleForRecord(TagRecord record) {

  double bestSize = 24;


  for (final zone in activeZones) {

    final centerDistance =
        math.sqrt(
          math.pow(
            record.latitude! - zone.centerLatitude,
            2,
          ) +
          math.pow(
            record.longitude! - zone.centerLongitude,
            2,
          ),
        );


    if (centerDistance < 0.01) {

      final radius =
          zoneRadiusPixels(zone);


      bestSize =
          radius * 0.18;

      break;

    }

  }


  for (final polygon in activePolygonZones) {

    final points =
        polygon.points;


    if(points.isEmpty){
      continue;
    }


    final xs =
        points.map(
          (e) => e.latitude,
        );


    final ys =
        points.map(
          (e) => e.longitude,
        );


    final width =
        (xs.reduce(math.max) -
         xs.reduce(math.min))
        .abs();


    final height =
        (ys.reduce(math.max) -
         ys.reduce(math.min))
        .abs();


    final areaSize =
        ((width + height) * 5000);


    if(areaSize > 0){

      bestSize =
          areaSize * 0.08;

    }

  }


  return bestSize.clamp(
    14.0,
    36.0,
  );

}






       double get clusterDistance {

         if (currentMapScale < 0.8) {

           // نمای خیلی دور
           return 0.003;

         }


         if (currentMapScale < 2.0) {

           // نمای متوسط
           return 0.001;

         }


         // نمای نزدیک
         return 0.00025;

       }




       @override
       void initState() {
         super.initState();

         transformationController.addListener(updateCurrentScale);

         if (widget.records.isNotEmpty) {
           selectedRecord = widget.records.first;
         }
         if (widget.routeTagId != null) {
           WidgetsBinding.instance.addPostFrameCallback((_) {
             if (!mounted) return;
             for (final r in widget.records) {
               if (r.tagId == widget.routeTagId) {
                 showRouteForRecord(r);
                 break;
               }
             }
           });
         }
       }

     @override
     void didUpdateWidget(covariant SimpleGpsMap oldWidget) {
       super.didUpdateWidget(oldWidget);

       final areaChanged =
           oldWidget.area?.id != widget.area?.id ||
           oldWidget.area?.northLatitude != widget.area?.northLatitude ||
           oldWidget.area?.southLatitude != widget.area?.southLatitude ||
           oldWidget.area?.eastLongitude != widget.area?.eastLongitude ||
           oldWidget.area?.westLongitude != widget.area?.westLongitude;

       if (oldWidget.focusedTagId != widget.focusedTagId) {
         focusExternalCamel();
       }
       if (oldWidget.routeTagId != widget.routeTagId ||
           (widget.routeTagId != null && !identical(oldWidget.trackRecords, widget.trackRecords))) {
         if (widget.routeTagId == null) {
           clearRouteMode();
         } else {
           for (final record in widget.records) {
             if (record.tagId == widget.routeTagId) {
               showRouteForRecord(record);
               break;
             }
           }
         }
       }
       final dataChanged = !listEquals(oldWidget.records, widget.records) ||
           !listEquals(oldWidget.zones, widget.zones) ||
           !listEquals(oldWidget.polygonZones, widget.polygonZones) || areaChanged;
       if (dataChanged) {
         _clusterCache = null;
         // A new GPS point must not reset the user's current pan/zoom.
         if (oldWidget.records.isEmpty && widget.records.isNotEmpty) {
           selectedRecord = widget.records.first;
           didFitInitialView = false;
         }
       }
     }


       @override
       void dispose() {
         transformationController.removeListener(updateCurrentScale);
         transformationController.dispose();
         super.dispose();
       }

     void focusExternalCamel() {
       final id = widget.focusedTagId;
       if (id == null) return;
       final records = widget.records.where((r) => r.tagId == id);
       if (records.isEmpty) return;
       WidgetsBinding.instance.addPostFrameCallback((_) {
         if (!mounted || viewportSize == Size.zero) return;
         zoomToRecord(records.first, showPhoto: true);
       });
     }

     List<PolygonZone> get activePolygonZones {
       return widget.polygonZones
           .where(
             (zone) => zone.isActive && zone.isValid,
           )
           .toList();
     }

       List<TagRecord> get mapRecords {
         return widget.records.where((record) {
           return record.latitude != null && record.longitude != null;
         }).toList();
       }

       List<TagRecord> get visibleMapRecords {
         final selectedRoute = routeRecord;

         if (selectedRoute == null) {
           return mapRecords;
         }

         final selected = mapRecords.where((record) {
           return record.tagId == selectedRoute.tagId;
         }).toList();

         if (selected.isNotEmpty) {
           return [
             selected.first,
           ];
         }

         if (selectedRoute.latitude != null &&
             selectedRoute.longitude != null) {
           return [
             selectedRoute,
           ];
         }

         return [];
       }


      List<CamelCluster> get camelClusters {
        return _clusterCache ??= MapClusterService.build(
          isRouteMode ? visibleMapRecords : mapRecords,
          widget.area, activeZones, activePolygonZones,
        ).map((group) => CamelCluster(
          latitude: group.latitude,
          longitude: group.longitude,
          zoneKey: group.zoneKey,
          zoneTitle: clusterZoneTitleForRecord(group.members.first),
          records: [...group.members],
        )).toList();
      }

       int get totalClusterCount {

         return camelClusters.length;

       }

       List<AreaZone> get activeZones {
         return widget.zones.where((zone) => zone.isActive).toList();
       }




       Widget buildRouteStatusBar() {
         if (!isRouteMode) {
           return const SizedBox.shrink();
         }

         return Positioned(
           top: 48,
           right: 10,
           left: 10,
           child: Container(
             padding: const EdgeInsets.symmetric(
               horizontal: 10,
               vertical: 8,
             ),
             decoration: BoxDecoration(
               color: Colors.white.withValues(alpha: 0.94),
               borderRadius: BorderRadius.circular(14),
               border: Border.all(
                 color: const Color(0xFFC8EBDD),
               ),
               boxShadow: [
                 BoxShadow(
                   color: Colors.black.withValues(alpha: 0.10),
                   blurRadius: 12,
                   offset: const Offset(0, 4),
                 ),
               ],
             ),
             child: Row(
               children: [
                 const Icon(
                   Icons.route_rounded,
                   color: Color(0xFF008B62),
                   size: 18,
                 ),

                 const SizedBox(width: 6),

                 Expanded(
                   child: Text(
                     routeInfoText,
                     maxLines: 1,
                     overflow: TextOverflow.ellipsis,
                     style: const TextStyle(
                       color: Color(0xFF062C5E),
                       fontWeight: FontWeight.bold,
                       fontSize: 11,
                     ),
                   ),
                 ),

                 const SizedBox(width: 6),

                 InkWell(
                   onTap: clearRouteMode,
                   borderRadius: BorderRadius.circular(20),
                   child: const Padding(
                     padding: EdgeInsets.all(3),
                     child: Icon(
                       Icons.close_rounded,
                       size: 18,
                       color: Color(0xFFD32F2F),
                     ),
                   ),
                 ),
               ],
             ),
           ),
         );
       }



       double degreesToRadians(double value) {
         return value * math.pi / 180.0;
       }

       double distanceMetersBetween({
         required double lat1,
         required double lng1,
         required double lat2,
         required double lng2,
       }) {
         const earthRadiusMeters = 6371000.0;

         final dLat = degreesToRadians(lat2 - lat1);
         final dLng = degreesToRadians(lng2 - lng1);

         final a =
             math.sin(dLat / 2) * math.sin(dLat / 2) +
             math.cos(degreesToRadians(lat1)) *
                 math.cos(degreesToRadians(lat2)) *
                 math.sin(dLng / 2) *
                 math.sin(dLng / 2);

         final c = 2 * math.atan2(
           math.sqrt(a),
           math.sqrt(1 - a),
         );

         return earthRadiusMeters * c;
       }

       bool isRecordInsideAreaZone(
         TagRecord record,
         AreaZone zone,
       ) {
         if (record.latitude == null || record.longitude == null) {
           return false;
         }

         final distance = distanceMetersBetween(
           lat1: record.latitude!,
           lng1: record.longitude!,
           lat2: zone.centerLatitude,
           lng2: zone.centerLongitude,
         );

         return distance <= zone.radiusMeters;
       }

       bool isPointInsidePolygonZone({
         required double latitude,
         required double longitude,
         required PolygonZone zone,
       }) {
         final points = zone.points;

         if (points.length < 3) {
           return false;
         }

         bool inside = false;
         int j = points.length - 1;

         for (int i = 0; i < points.length; i++) {
           final xi = points[i].longitude;
           final yi = points[i].latitude;

           final xj = points[j].longitude;
           final yj = points[j].latitude;

           final intersects =
               ((yi > latitude) != (yj > latitude)) &&
               (longitude <
                   (xj - xi) *
                           (latitude - yi) /
                           ((yj - yi) == 0 ? 0.0000001 : (yj - yi)) +
                       xi);

           if (intersects) {
             inside = !inside;
           }

           j = i;
         }

         return inside;
       }

       double polygonApproxSize(
         PolygonZone zone,
       ) {
         if (zone.points.isEmpty) {
           return double.infinity;
         }

         final lats = zone.points.map((p) => p.latitude).toList();
         final lngs = zone.points.map((p) => p.longitude).toList();

         final latRange =
             lats.reduce(math.max) - lats.reduce(math.min);

         final lngRange =
             lngs.reduce(math.max) - lngs.reduce(math.min);

         return latRange.abs() * lngRange.abs();
       }

       String clusterZoneKeyForRecord(TagRecord record) {
         if (record.latitude == null || record.longitude == null) {
           return 'no_location';
         }

         final containingPolygons = activePolygonZones.where((zone) {
           return isPointInsidePolygonZone(
             latitude: record.latitude!,
             longitude: record.longitude!,
             zone: zone,
           );
         }).toList()
           ..sort(
             (a, b) => polygonApproxSize(a).compareTo(
               polygonApproxSize(b),
             ),
           );

         if (containingPolygons.isNotEmpty) {
           return 'polygon_${containingPolygons.first.id}';
         }

         final containingAreaZones = activeZones.where((zone) {
           return isRecordInsideAreaZone(record, zone);
         }).toList()
           ..sort(
             (a, b) => a.radiusMeters.compareTo(b.radiusMeters),
           );

         if (containingAreaZones.isNotEmpty) {
           return 'area_${containingAreaZones.first.id}';
         }

         return 'outside';
       }

       String clusterZoneTitleForRecord(TagRecord record) {
         if (record.latitude == null || record.longitude == null) {
           return 'بدون موقعیت';
         }

         final containingPolygons = activePolygonZones.where((zone) {
           return isPointInsidePolygonZone(
             latitude: record.latitude!,
             longitude: record.longitude!,
             zone: zone,
           );
         }).toList()
           ..sort(
             (a, b) => polygonApproxSize(a).compareTo(
               polygonApproxSize(b),
             ),
           );

         if (containingPolygons.isNotEmpty) {
           return containingPolygons.first.name;
         }

         final containingAreaZones = activeZones.where((zone) {
           return isRecordInsideAreaZone(record, zone);
         }).toList()
           ..sort(
             (a, b) => a.radiusMeters.compareTo(b.radiusMeters),
           );

         if (containingAreaZones.isNotEmpty) {
           return containingAreaZones.first.name;
         }

         return 'خارج از محدوده';
       }


      double getContainingZoneSize(
        TagRecord record,
      ) {
        double baseSize = 26;


        // اگر مختصات نداشت، اندازه امن بده
        if (record.latitude == null || record.longitude == null) {
          return 18;
        }


        // 1) اثر تعداد شترها
        // هرچه شترها بیشتر باشند، marker کوچک‌تر می‌شود.
        final camelCount =
            mapRecords.length;


        final densityFactor =
            camelCount <= 20
                ? 1.0
                : camelCount <= 60
                    ? 0.85
                    : camelCount <= 150
                        ? 0.70
                        : 0.55;



        // 2) اثر zoom
        // در zoom پایین کوچک‌تر، در zoom بالا کمی بزرگ‌تر
        final zoomFactor =
            currentMapScale < 0.8
                ? 0.65
                : currentMapScale < 1.5
                    ? 0.82
                    : currentMapScale < 2.8
                        ? 1.0
                        : 1.15;



        // 3) اثر محدوده دایره‌ای
        for (final zone in activeZones) {
          final distance =
              math.sqrt(
                math.pow(
                  record.latitude! - zone.centerLatitude,
                  2,
                ) +
                    math.pow(
                      record.longitude! - zone.centerLongitude,
                      2,
                    ),
              );

          if (distance < 0.01) {
            final radius =
                zoneRadiusPixels(zone);

            baseSize =
                (radius * 0.10).clamp(14.0, 30.0);
          }
        }



        // 4) اثر محدوده چندضلعی
        for (final polygon in activePolygonZones) {
          if (polygon.points.length < 3) {
            continue;
          }

          final offsets =
              polygon.points
                  .map(
                    (point) => positionForLatLng(
                      latitude: point.latitude,
                      longitude: point.longitude,
                    ),
                  )
                  .toList();

          final minX =
              offsets.map((e) => e.dx).reduce(math.min);

          final maxX =
              offsets.map((e) => e.dx).reduce(math.max);

          final minY =
              offsets.map((e) => e.dy).reduce(math.min);

          final maxY =
              offsets.map((e) => e.dy).reduce(math.max);

          final polygonVisualSize =
              math.min(
                maxX - minX,
                maxY - minY,
              );

          if (polygonVisualSize > 0) {
            baseSize =
                (polygonVisualSize * 0.08).clamp(13.0, 32.0);
          }
        }



        final finalSize =
            baseSize *
            densityFactor *
            zoomFactor;


        return finalSize.clamp(
          10.0,
          34.0,
        );
      }



       void updateCurrentScale() {
         final nextScale = transformationController.value.getMaxScaleOnAxis();

         if ((nextScale - currentMapScale).abs() < 0.03) return;

         setState(() {
           currentMapScale = nextScale;
         });
       }

       bool isSameRecord(TagRecord a, TagRecord b) {
         return a.tagId == b.tagId &&
             a.receivedDateTime == b.receivedDateTime &&
             a.receivedTime == b.receivedTime;
       }

       double metersToLatitudeDegree(double meters) {
         return meters / 111320.0;
       }

       double metersToLongitudeDegree({
         required double meters,
         required double latitude,
       }) {
         final latitudeRadians = latitude * math.pi / 180.0;
         final metersPerDegree = 111320.0 * math.cos(latitudeRadians).abs();

         if (metersPerDegree < 1) {
           return meters / 111320.0;
         }

         return meters / metersPerDegree;
       }

       List<_GpsPoint> zoneBoundaryPoints(AreaZone zone) {
         final latDelta = metersToLatitudeDegree(zone.radiusMeters);
         final lngDelta = metersToLongitudeDegree(
           meters: zone.radiusMeters,
           latitude: zone.centerLatitude,
         );

         return [
           _GpsPoint(
             latitude: zone.centerLatitude,
             longitude: zone.centerLongitude,
           ),
           _GpsPoint(
             latitude: zone.centerLatitude + latDelta,
             longitude: zone.centerLongitude,
           ),
           _GpsPoint(
             latitude: zone.centerLatitude - latDelta,
             longitude: zone.centerLongitude,
           ),
           _GpsPoint(
             latitude: zone.centerLatitude,
             longitude: zone.centerLongitude + lngDelta,
           ),
           _GpsPoint(
             latitude: zone.centerLatitude,
             longitude: zone.centerLongitude - lngDelta,
           ),
         ];
       }

      List<_GpsPoint> mapBoundaryPoints() {
        final points = <_GpsPoint>[];

        final area = widget.area;

        if (area != null) {
          points.add(
            _GpsPoint(
              latitude: area.northLatitude,
              longitude: area.westLongitude,
            ),
          );

          points.add(
            _GpsPoint(
              latitude: area.northLatitude,
              longitude: area.eastLongitude,
            ),
          );

          points.add(
            _GpsPoint(
              latitude: area.southLatitude,
              longitude: area.westLongitude,
            ),
          );

          points.add(
            _GpsPoint(
              latitude: area.southLatitude,
              longitude: area.eastLongitude,
            ),
          );

          points.add(
            _GpsPoint(
              latitude: area.centerLatitude,
              longitude: area.centerLongitude,
            ),
          );
        }

        for (final record in mapRecords) {
          points.add(
            _GpsPoint(
              latitude: record.latitude!,
              longitude: record.longitude!,
            ),
          );
        }


        for (final record in routeRecords) {
          if (record.latitude == null || record.longitude == null) {
            continue;
          }

          points.add(
            _GpsPoint(
              latitude: record.latitude!,
              longitude: record.longitude!,
            ),
          );
        }

        for (final zone in activeZones) {
          points.addAll(
            zoneBoundaryPoints(zone),
          );
        }

        for (final polygonZone in activePolygonZones) {
          for (final point in polygonZone.points) {
            points.add(
              _GpsPoint(
                latitude: point.latitude,
                longitude: point.longitude,
              ),
            );
          }
        }

        return points;
      }

      _GpsBounds boundsForMap() {
        final points = mapBoundaryPoints();

       if(points.isEmpty){

         final area = widget.area;

         if(area != null){
           return _GpsBounds(
             minLat: area.southLatitude,
             maxLat: area.northLatitude,
             minLng: area.westLongitude,
             maxLng: area.eastLongitude,
           ).withPadding(0.15);
         }


         return const _GpsBounds(
           minLat: 31.0,
           maxLat: 32.0,
           minLng: 54.0,
           maxLng: 55.0,
         );
       }

        var minLat = points.first.latitude;
        var maxLat = points.first.latitude;
        var minLng = points.first.longitude;
        var maxLng = points.first.longitude;

        for (final point in points) {
          if (point.latitude < minLat) minLat = point.latitude;
          if (point.latitude > maxLat) maxLat = point.latitude;
          if (point.longitude < minLng) minLng = point.longitude;
          if (point.longitude > maxLng) maxLng = point.longitude;
        }

        final padding = widget.area == null ? 0.25 : 0.06;

        return _GpsBounds(
          minLat: minLat,
          maxLat: maxLat,
          minLng: minLng,
          maxLng: maxLng,
        ).withPadding(padding);
      }

       Offset positionForLatLng({
         required double latitude,
         required double longitude,
       }) {
         final bounds = boundsForMap();

         const margin = 90.0;

         final usableWidth = sceneWidth - margin * 2;
         final usableHeight = sceneHeight - margin * 2;

         final x = margin +
             ((longitude - bounds.minLng) / bounds.lngRange) * usableWidth;

         final y = margin +
             ((bounds.maxLat - latitude) / bounds.latRange) * usableHeight;

         return Offset(x, y);
       }

       Offset positionFor(TagRecord record) {
         return positionForLatLng(
           latitude: record.latitude!,
           longitude: record.longitude!,
         );
       }

       Color zoneColor(AreaZone zone) {
         switch (zone.type) {
           case AreaZoneType.stable:
             return const Color(0xFF7B3FB3);
           case AreaZoneType.pasture:
             return const Color(0xFF008B62);
           case AreaZoneType.water:
             return const Color(0xFF086EBB);
           case AreaZoneType.route:
             return const Color(0xFFE87500);
           case AreaZoneType.forbidden:
             return const Color(0xFFD32F2F);
         }
       }

       double zoneRadiusPixels(AreaZone zone) {
         final center = positionForLatLng(
           latitude: zone.centerLatitude,
           longitude: zone.centerLongitude,
         );

         final latOffset = metersToLatitudeDegree(zone.radiusMeters);
         final lngOffset = metersToLongitudeDegree(
           meters: zone.radiusMeters,
           latitude: zone.centerLatitude,
         );

         final northPoint = positionForLatLng(
           latitude: zone.centerLatitude + latOffset,
           longitude: zone.centerLongitude,
         );

         final eastPoint = positionForLatLng(
           latitude: zone.centerLatitude,
           longitude: zone.centerLongitude + lngOffset,
         );

         final radiusY = (northPoint.dy - center.dy).abs();
         final radiusX = (eastPoint.dx - center.dx).abs();

         return ((radiusX + radiusY) / 2).clamp(18.0, 520.0).toDouble();
       }

      Widget buildZoneShape(AreaZone zone) {

        final center =
            positionForLatLng(
              latitude: zone.centerLatitude,
              longitude: zone.centerLongitude,
            );


        final radius =
            zoneRadiusPixels(zone);


        final color =
            zoneColor(zone);



        return Positioned(

          left: center.dx - radius,

          top: center.dy - radius,


          child: IgnorePointer(

            child: Container(

              width: radius * 2,

              height: radius * 2,


              decoration: BoxDecoration(

                shape: BoxShape.circle,


                color:
                    color.withValues(alpha: 0.08),


                border: Border.all(

                  color:
                      color.withValues(alpha: 0.55),

                  width: 1.4,

                ),

              ),

            ),

          ),

        );

      }




   Widget buildAreaZoneLabel(
     AreaZone zone,
   ) {

     final center =
         positionForLatLng(
           latitude: zone.centerLatitude,
           longitude: zone.centerLongitude,
         );


     final detail =
         currentDetailLevel;



     if (detail == MapDetailLevel.low) {

       return const SizedBox.shrink();

     }



     final text =
         detail == MapDetailLevel.high
             ? zone.name
             : zone.typeText;



     return Positioned(

       left: center.dx - 45,

       top: center.dy - 15,


       child: IgnorePointer(

         child: Container(

           constraints:
               const BoxConstraints(
                 maxWidth: 100,
               ),


           padding:
               const EdgeInsets.symmetric(
                 horizontal: 6,
                 vertical: 3,
               ),


           decoration:
               BoxDecoration(

                 color:
                     Colors.white.withValues(alpha: 0.85),


                 borderRadius:
                     BorderRadius.circular(8),


                 border:
                     Border.all(
                       color:
                           zoneColor(zone)
                               .withValues(alpha: 0.25),
                     ),

               ),


           child: Text(

             text,

             maxLines: 1,

             overflow:
                 TextOverflow.ellipsis,


             textAlign:
                 TextAlign.center,


             style:
                 TextStyle(

               color:
                   zoneColor(zone),


               fontWeight:
                   FontWeight.bold,


               fontSize:
                   detail == MapDetailLevel.high
                       ? 7
                       : 5,

             ),

           ),

         ),

       ),

     );

   }





     Widget buildSelectedAreaShape() {
       if (!widget.drawAreaBounds) return const SizedBox.shrink();
       final area = widget.area;

       if (area == null) {
         return const SizedBox.shrink();
       }

       final northWest = positionForLatLng(
         latitude: area.northLatitude,
         longitude: area.westLongitude,
       );

       final southEast = positionForLatLng(
         latitude: area.southLatitude,
         longitude: area.eastLongitude,
       );

       final left = math.min(
         northWest.dx,
         southEast.dx,
       );

       final top = math.min(
         northWest.dy,
         southEast.dy,
       );

       final width = (southEast.dx - northWest.dx).abs();
       final height = (southEast.dy - northWest.dy).abs();

       return Positioned(
         left: left,
         top: top,
         child: IgnorePointer(
           child: Container(
             width: width,
             height: height,
             decoration: BoxDecoration(
               color: const Color(0xFF008B62).withValues(alpha: 0.018),
               borderRadius: BorderRadius.circular(10),
               border: Border.all(
                 color: const Color(0xFF008B62).withValues(alpha: 0.35),
                 width: 1.1,
               ),
             ),
           ),
         ),
       );
     }


      Color polygonZoneColor(
        PolygonZoneType type,
      ) {
        switch (type) {
          case PolygonZoneType.grazing:
            return const Color(0xFF008B62);

          case PolygonZoneType.barn:
            return const Color(0xFF795548);

          case PolygonZoneType.forbidden:
            return const Color(0xFFD32F2F);

          case PolygonZoneType.water:
            return const Color(0xFF086EBB);

          case PolygonZoneType.custom:
            return const Color(0xFF6A1B9A);
        }
      }



      String polygonZoneLabel(
        PolygonZoneType type,
      ) {
        switch (type) {
          case PolygonZoneType.grazing:
            return 'چراگاه';

          case PolygonZoneType.barn:
            return 'آغل';

          case PolygonZoneType.forbidden:
            return 'ممنوع';

          case PolygonZoneType.water:
            return 'آبشخور';

          case PolygonZoneType.custom:
            return 'سفارشی';
        }
      }



     Widget buildPolygonZoneShape(
       PolygonZone zone,
     ) {

       if (!zone.isValid) {
         return const SizedBox.shrink();
       }


       final offsets =
           zone.points
               .map(
                 (point) => positionForLatLng(
                   latitude: point.latitude,
                   longitude: point.longitude,
                 ),
               )
               .toList();



       final minX =
           offsets
               .map((e) => e.dx)
               .reduce(math.min);


       final maxX =
           offsets
               .map((e) => e.dx)
               .reduce(math.max);



       final minY =
           offsets
               .map((e) => e.dy)
               .reduce(math.min);


       final maxY =
           offsets
               .map((e) => e.dy)
               .reduce(math.max);



              const padding = 20.0;



      final localPoints =
          offsets.map(
            (point) => Offset(
              point.dx - minX + padding,
              point.dy - minY + padding,
            ),
          ).toList();
      final localHoles = zone.holes.map((ring) => ring.map((point) {
        final p = positionForLatLng(
          latitude: point.latitude, longitude: point.longitude);
        return Offset(p.dx - minX + padding, p.dy - minY + padding);
      }).toList()).toList();



    return Positioned(

      left: minX - padding,

      top: minY - padding,


      width:
          (maxX - minX) + (padding * 2),


      height:
          (maxY - minY) + (padding * 2),


      child: GestureDetector(

        onTap: () {

          zoomToPolygonZone(zone);

        },


        child: SizedBox(

          width:
              (maxX - minX) + (padding * 2),


          height:
              (maxY - minY) + (padding * 2),


          child: CustomPaint(

            painter: _PolygonZonePainter(

              offsets: localPoints,
              holeOffsets: localHoles,

              color:
                  polygonZoneColor(
                    zone.type,
                  ),

            ),

          ),

        ),

      ),

    );

    }


    Widget buildPolygonZoneLabel(
      PolygonZone zone,
    ) {

      final offsets = zone.points
          .map(
            (point) => positionForLatLng(
              latitude: point.latitude,
              longitude: point.longitude,
            ),
          )
          .toList();


      if (offsets.isEmpty) {
        return const SizedBox.shrink();
      }



      double centerX = 0;
      double centerY = 0;


      for (final point in offsets) {

        centerX += point.dx;
        centerY += point.dy;

      }


      final center = Offset(
        centerX / offsets.length,
        centerY / offsets.length,
      );



      final detail =
          currentDetailLevel;



      // در Zoom کم هیچ متنی نداریم

      if (detail == MapDetailLevel.low) {

        return const SizedBox.shrink();

      }



      String text;



      if(detail == MapDetailLevel.medium){

        text =
            polygonZoneLabel(
              zone.type,
            );

      }

      else {

        text =
            zone.name;

      }



      return Positioned(

        left: center.dx - 50,

        top: center.dy - 18,


        child: IgnorePointer(

          child: Container(

            constraints:
                const BoxConstraints(
                 maxWidth: 80,
                ),


            padding:
                const EdgeInsets.symmetric(
                 horizontal: 4,
                 vertical: 2,
                ),


            decoration:
                BoxDecoration(

                  color:
                      Colors.white.withValues(alpha: 
                        0.88,
                      ),

                  borderRadius:
                      BorderRadius.circular(10),


                  border:
                      Border.all(
                        color:
                            polygonZoneColor(
                              zone.type,
                            ).withValues(alpha: .25),
                      ),

                ),


            child: Text(

              text,

              maxLines: 1,

              overflow:
                  TextOverflow.ellipsis,


              textAlign:
                  TextAlign.center,


              style:
                  TextStyle(

               fontSize:
                   detail == MapDetailLevel.high
                       ? 8
                       : 6,


                fontWeight:
                    FontWeight.bold,


                color:
                    polygonZoneColor(
                      zone.type,
                    ),

              ),

            ),

          ),

        ),

      );

    }


      void fitAll(Size size) {
      if (size.width <= 0 ||
              size.height <= 0) {
        return;
      }

        final scaleX = size.width / sceneWidth;
        final scaleY = size.height / sceneHeight;
        final baseScale = scaleX < scaleY ? scaleX : scaleY;
        final scale = baseScale * 0.96;

        final dx = (size.width - sceneWidth * scale) / 2;
        final dy = (size.height - sceneHeight * scale) / 2;

        transformationController.value = Matrix4.identity()
          ..translate(dx, dy)
          ..scale(scale);

        currentMapScale = scale;
      }



      DateTime? routeDateTime(TagRecord record) {
        final text = record.receivedDateTime.trim();

        if (text.isEmpty) {
          return null;
        }

        return IranTime.parseForDisplay(text);
      }

      void showRouteForRecord(TagRecord record) {
        _clusterCache = null;
        if (widget.routeTagId != record.tagId && widget.onRouteRequest != null) {
          widget.onRouteRequest!(record);
          return;
        }
        final points = widget.trackRecords.where((item) {
          return item.tagId == record.tagId &&
              item.latitude != null &&
              item.longitude != null;
        }).toList();

        points.sort((a, b) {
          final aTime = routeDateTime(a);
          final bTime = routeDateTime(b);

          if (aTime == null && bTime == null) {
            return 0;
          }

          if (aTime == null) {
            return 1;
          }

          if (bTime == null) {
            return -1;
          }

          return aTime.compareTo(bTime);
        });

        setState(() {
          routeRecord = record;
          routeRecords = points;
          selectedRecord = record;
          showSelectedCamelPhoto = false;
          selectedCamelDetail = null;
          selectedCamelPhotoError = null;
          isLoadingSelectedCamelDetail = false;
        });

        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (!mounted) return;

          if (routeRecords.length >= 2) {
            zoomToRoute(routeRecords);
          } else {
            zoomToRecord(record);
          }
        });
      }



      String routePointTimeText(TagRecord record) {
        final parsed = IranTime.parseForDisplay(record.receivedDateTime);

        if (parsed == null) {
          return record.receivedTime;
        }

        final hour = parsed.hour.toString().padLeft(2, '0');
        final minute = parsed.minute.toString().padLeft(2, '0');

        return '$hour:$minute';
      }

      String get routeStartText {
        if (routeRecords.isEmpty) {
          return '-';
        }

        return routePointTimeText(routeRecords.first);
      }

      String get routeEndText {
        if (routeRecords.isEmpty) {
          return '-';
        }

        return routePointTimeText(routeRecords.last);
      }

      String get routeInfoText {
        final record = routeRecord;

        if (record == null) {
          return '';
        }

        if (routeRecords.isEmpty) {
          return 'برای شتر ${record.camelNo} امروز مسیر ثبت نشده است.';
        }

        if (routeRecords.length == 1) {
          return 'مسیر شتر ${record.camelNo} • فقط ۱ نقطه ثبت شده';
        }

        return 'مسیر شتر ${record.camelNo} • ${routeRecords.length} نقطه • $routeStartText تا $routeEndText';
      }




      void clearRouteMode() {
        _clusterCache = null;
        setState(() {
          routeRecord = null;
          routeRecords = [];
        });
      }

      void zoomToRoute(List<TagRecord> records) {
        if (records.isEmpty ||
            viewportSize.width <= 0 ||
            viewportSize.height <= 0) {
          return;
        }

        final points = records
            .where((record) {
              return record.latitude != null && record.longitude != null;
            })
            .map(positionFor)
            .toList();

        if (points.isEmpty) {
          return;
        }

        double minX = points.first.dx;
        double maxX = points.first.dx;
        double minY = points.first.dy;
        double maxY = points.first.dy;

        for (final point in points) {
          if (point.dx < minX) minX = point.dx;
          if (point.dx > maxX) maxX = point.dx;
          if (point.dy < minY) minY = point.dy;
          if (point.dy > maxY) maxY = point.dy;
        }

        final routeWidth = (maxX - minX).abs().clamp(40.0, sceneWidth);
        final routeHeight = (maxY - minY).abs().clamp(40.0, sceneHeight);

        final scaleX = viewportSize.width / routeWidth;
        final scaleY = viewportSize.height / routeHeight;

        final scale = (math.min(scaleX, scaleY) * 0.55)
            .clamp(1.2, 5.0)
            .toDouble();

        final centerX = (minX + maxX) / 2;
        final centerY = (minY + maxY) / 2;

        final dx = viewportSize.width / 2 - centerX * scale;
        final dy = viewportSize.height / 2 - centerY * scale;

        transformationController.value = Matrix4.identity()
          ..translate(dx, dy)
          ..scale(scale);

        setState(() {
          currentMapScale = scale;
        });
      }




       void scheduleFitAll(Size size) {
         if (didFitInitialView) return;

         didFitInitialView = true;

         WidgetsBinding.instance.addPostFrameCallback((_) {
           if (!mounted) return;
           fitAll(size);
         });
       }

      void zoomToRecord(
        TagRecord record, {
        bool showPhoto = false,
      }) {
        if (viewportSize.width <= 0 || viewportSize.height <= 0) return;

        final point = positionFor(record);

        const zoomScale = 3.4;

        final dx = viewportSize.width / 2 - point.dx * zoomScale;
        final dy = viewportSize.height / 2 - point.dy * zoomScale;

        setState(() {
          selectedRecord = record;
          showSelectedCamelPhoto = showPhoto;

          if (!showPhoto) {
            selectedCamelDetail = null;
            selectedCamelPhotoError = null;
            isLoadingSelectedCamelDetail = false;
          }

          transformationController.value = Matrix4.identity()
            ..translate(dx, dy)
            ..scale(zoomScale);

          currentMapScale = zoomScale;
        });

        if (showPhoto) {
          loadSelectedCamelDetail(record);
        }
      }





        void zoomToPolygonZone(
          PolygonZone zone,
        ) {

          if (zone.points.isEmpty) {
            return;
          }


          final points =
              zone.points
                  .map(
                    (point) =>
                        positionForLatLng(
                          latitude: point.latitude,
                          longitude: point.longitude,
                        ),
                  )
                  .toList();



          final minX =
              points.map((e) => e.dx).reduce(math.min);

          final maxX =
              points.map((e) => e.dx).reduce(math.max);


          final minY =
              points.map((e) => e.dy).reduce(math.min);


          final maxY =
              points.map((e) => e.dy).reduce(math.max);



          final centerX =
              (minX + maxX) / 2;


          final centerY =
              (minY + maxY) / 2;



          final polygonWidth =
              maxX - minX;


          final polygonHeight =
              maxY - minY;



          if (viewportSize.width <= 0 ||
              viewportSize.height <= 0) {
            return;
          }



          final scaleX =
              viewportSize.width /
              polygonWidth;


          final scaleY =
              viewportSize.height /
              polygonHeight;



          final targetScale =
              math.min(scaleX, scaleY) * 0.65;



          final scale =
              targetScale.clamp(
                1.2,
                5.0,
              );



          final dx =
              viewportSize.width / 2 -
              centerX * scale;


          final dy =
              viewportSize.height / 2 -
              centerY * scale;



          transformationController.value =
              Matrix4.identity()
                ..translate(dx, dy)
                ..scale(scale);



          currentMapScale = scale;

        }



      void zoomToCluster(
        CamelCluster cluster,
      ) {

        final center =
            positionForLatLng(
              latitude: cluster.latitude,
              longitude: cluster.longitude,
            );


        const zoomScale = 2.8;


        final dx =
            viewportSize.width / 2 -
            center.dx * zoomScale;


        final dy =
            viewportSize.height / 2 -
            center.dy * zoomScale;



        transformationController.value =
            Matrix4.identity()
              ..translate(dx, dy)
              ..scale(zoomScale);



        setState(() {

          currentMapScale = zoomScale;

        });

      }



      void changeZoom(double factor) {
        if (viewportSize.width <= 0 || viewportSize.height <= 0) return;

        final currentScale =
            transformationController.value.getMaxScaleOnAxis();

        final nextScale =
            (currentScale * factor).clamp(0.20, 8.0).toDouble();

        final center = Offset(
          viewportSize.width / 2,
          viewportSize.height / 2,
        );

        final sceneCenter =
            transformationController.toScene(center);

        final dx = center.dx - sceneCenter.dx * nextScale;
        final dy = center.dy - sceneCenter.dy * nextScale;

        transformationController.value = Matrix4.identity()
          ..translate(dx, dy)
          ..scale(nextScale);

        currentMapScale = nextScale;
      }

       Future<void> copySelectedGps(BuildContext context) async {
         final record = selectedRecord;

         if (record == null || record.latitude == null || record.longitude == null) {
           ScaffoldMessenger.of(context).showSnackBar(
             const SnackBar(
               content: Text('مختصاتی برای کپی وجود ندارد.'),
             ),
           );
           return;
         }

         final text =
             '${record.latitude!.toStringAsFixed(6)},${record.longitude!.toStringAsFixed(6)}';

         await Clipboard.setData(
           ClipboardData(text: text),
         );

         if (!context.mounted) return;

         ScaffoldMessenger.of(context).showSnackBar(
           const SnackBar(
             content: Text('مختصات GPS کپی شد.'),
           ),
         );
       }


        double get safeMapScale {
          if (currentMapScale.isNaN ||
              currentMapScale.isInfinite ||
              currentMapScale <= 0) {
            return 1.0;
          }

          return currentMapScale;
        }

        double screenToScene(double value) {
          return value / safeMapScale;
        }

        double camelMarkerScreenSize(
          MapDetailLevel detail,
        ) {
          final count = mapRecords.length;

          if (count > 250) {
            return detail == MapDetailLevel.high
                ? 10.0
                : detail == MapDetailLevel.medium
                    ? 8.0
                    : 6.0;
          }

          if (count > 80) {
            return detail == MapDetailLevel.high
                ? 12.0
                : detail == MapDetailLevel.medium
                    ? 9.0
                    : 7.0;
          }

          return detail == MapDetailLevel.high
              ? 14.0
              : detail == MapDetailLevel.medium
                  ? 11.0
                  : 8.0;
        }

        bool shouldShowCamelNumberOnMap() {
          final count = mapRecords.length;

          if (currentMapScale < 2.4) {
            return false;
          }

          if (count <= 40) {
            return true;
          }

          if (count <= 120) {
            return currentMapScale >= 3.2;
          }

          return currentMapScale >= 5.0;
        }

        double camelNumberScreenFontSize() {
          final count = mapRecords.length;

          if (count > 150) {
            return 5.5;
          }

          if (count > 60) {
            return 6.0;
          }

          return 6.5;
        }

        Offset spreadPointForRecord(
          TagRecord record,
        ) {
          final basePoint = positionFor(record);

          final threshold =
              screenToScene(10);

         final nearRecords =
             visibleMapRecords.where(
               (other) {
                  final otherPoint =
                      positionFor(other);

                  return (otherPoint - basePoint).distance <= threshold;
                },
              ).toList();

          if (nearRecords.length <= 1) {
            return basePoint;
          }

          nearRecords.sort(
            (a, b) {
              final camelCompare =
                  a.camelNo.compareTo(b.camelNo);

              if (camelCompare != 0) {
                return camelCompare;
              }

              return a.tagId.compareTo(b.tagId);
            },
          );

          final index =
              nearRecords.indexWhere(
                (other) => isSameRecord(
                  other,
                  record,
                ),
              );

          if (index < 0) {
            return basePoint;
          }

          final ring =
              math.min(
                (index ~/ 8) + 1,
                3,
              );

          final indexInRing =
              index % 8;

          final angle =
              (math.pi * 2 * indexInRing) / 8;

          final radius =
              screenToScene(
                9.0 * ring,
              );

          return Offset(
            basePoint.dx + math.cos(angle) * radius,
            basePoint.dy + math.sin(angle) * radius,
          );
        }


      Widget buildTagMarker(TagRecord record) {
        final point =
            spreadPointForRecord(record);

        final isLowBattery =
            record.isBatteryLow;

        final isUnlocked =
            record.lock == 0;

        final color =
            isUnlocked
                ? const Color(0xFFD32F2F)
                : isLowBattery
                    ? const Color(0xFFE87500)
                    : const Color(0xFF008B62);

        final detail =
            currentDetailLevel;

        final markerScreenSize =
            camelMarkerScreenSize(detail);

        final markerSize =
            screenToScene(markerScreenSize);

        final iconSize =
            screenToScene(markerScreenSize * 0.55);

        final borderWidth =
            screenToScene(
              detail == MapDetailLevel.high ? 1.2 : 0.8,
            );

        final showCamelNumber =
            shouldShowCamelNumberOnMap();

        return Positioned(
          left: point.dx - markerSize / 2,
          top: point.dy - markerSize / 2,

          child: GestureDetector(
            onTap: () {
              zoomToRecord(
                record,
                showPhoto: false,
              );
            },

            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: markerSize,
                  height: markerSize,

                  decoration: BoxDecoration(
                    color: color,
                    shape: BoxShape.circle,

                    border: Border.all(
                      color: Colors.white,
                      width: borderWidth,
                    ),

                    boxShadow: [
                      BoxShadow(
                        color: color.withValues(alpha: 0.28),
                        blurRadius: screenToScene(4),
                      ),
                    ],
                  ),

                  child: detail == MapDetailLevel.low
                      ? null
                      : Icon(
                          isUnlocked
                              ? Icons.lock_open_rounded
                              : Icons.pets_rounded,
                          color: Colors.white,
                          size: iconSize,
                        ),
                ),

                if (showCamelNumber)
                  Container(
                    margin: EdgeInsets.only(
                      top: screenToScene(1.5),
                    ),

                    padding: EdgeInsets.symmetric(
                      horizontal: screenToScene(2.5),
                      vertical: screenToScene(0.8),
                    ),

                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.82),
                      borderRadius: BorderRadius.circular(
                        screenToScene(3),
                      ),
                    ),

                    child: Text(
                      record.camelNo,
                      style: TextStyle(
                        color: const Color(0xFF062C5E),
                        fontWeight: FontWeight.bold,
                        fontSize: screenToScene(
                          camelNumberScreenFontSize(),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        );
      }




       Widget buildClusterMarker(
         CamelCluster cluster,
       ) {

         final point =
             positionForLatLng(

               latitude:
                   cluster.latitude,

               longitude:
                   cluster.longitude,

             );

             final clusterSize =
                 currentMapScale < 1
                     ? 28.0
                     : currentMapScale < 2
                         ? 34.0
                         : 42.0;


         return Positioned(

        left: point.dx - clusterSize / 2,
        top: point.dy - clusterSize / 2,


           child: GestureDetector(

             onTap: () {

               zoomToCluster(cluster);

             },


             child: Container(

           width: clusterSize,
           height: clusterSize,

               decoration: BoxDecoration(

                 color:
                     const Color(0xFF086EBB),


                 shape:
                     BoxShape.circle,


                 border:
                     Border.all(
                       color: Colors.white,
                       width: 3,
                     ),


                 boxShadow: [

                   BoxShadow(

                     color:
                         Colors.black.withValues(alpha: .25),

                     blurRadius: 10,

                   )

                 ],

               ),


               child: Center(

                 child: Text(

                   cluster.count.toString(),


                   style:
                       const TextStyle(

                     color:
                         Colors.white,

                     fontWeight:
                         FontWeight.bold,

                     fontSize: 14,

                   ),

                 ),

               ),

             ),

           ),

         );

       }

        Future<void> loadSelectedCamelDetail(
          TagRecord record,
        ) async {
          setState(() {
            isLoadingSelectedCamelDetail = true;
            selectedCamelDetail = null;
            selectedCamelPhotoError = null;
          });

          try {
            final detail =
                await CamelDetailService.getDetailByTagId(
                  record.tagId,
                );

            if (!mounted) return;

            final rawPhotoPath =
                detail?.photoPath;

            final photoPath =
                rawPhotoPath == null
                    ? ''
                    : rawPhotoPath.trim();

            setState(() {
              selectedCamelDetail = detail;
              isLoadingSelectedCamelDetail = false;

              if (detail == null) {
                selectedCamelPhotoError =
                    'برای تگ ${record.tagId} اطلاعات شتر ثبت نشده است.';
              } else if (photoPath.isEmpty) {
                selectedCamelPhotoError =
                    'برای این شتر عکس ثبت نشده است.';
              } else if (!File(photoPath).existsSync()) {
                selectedCamelPhotoError =
                    'فایل عکس در حافظه پیدا نشد.';
              }
            });
          } catch (_) {
            if (!mounted) return;

            setState(() {
              isLoadingSelectedCamelDetail = false;
              selectedCamelPhotoError =
                  'خطا در خواندن اطلاعات شتر.';
            });
          }
        }


       Widget buildSelectedRecordPanel(BuildContext context) {
         final record = selectedRecord;


         final rawPhotoPath =
             selectedCamelDetail?.photoPath;

         final selectedPhotoPath =
             rawPhotoPath == null
                 ? ''
                 : rawPhotoPath.trim();

         if (record == null) {
           return Container(
             width: double.infinity,
             padding: const EdgeInsets.all(12),
             decoration: BoxDecoration(
               color: const Color(0xFFF5F7FA),
               borderRadius: BorderRadius.circular(14),
             ),
             child: const Text(
               'برای دیدن جزئیات، روی یک تگ روی نقشه بزن.',
               textAlign: TextAlign.center,
               style: TextStyle(
                 color: Colors.black54,
                 fontWeight: FontWeight.bold,
               ),
             ),
           );
         }

         final gpsText =
             '${record.latitude!.toStringAsFixed(6)}, ${record.longitude!.toStringAsFixed(6)}';

         return Container(
           width: double.infinity,
           padding: const EdgeInsets.all(12),
           decoration: BoxDecoration(
             color: const Color(0xFFEAF8F2),
             borderRadius: BorderRadius.circular(14),
             border: Border.all(
               color: const Color(0xFFC8EBDD),
             ),
           ),
           child: Column(
             crossAxisAlignment: CrossAxisAlignment.start,
             children: [
               Row(
                 children: [
                   CircleAvatar(
                     radius: 20,
                     backgroundColor: const Color(0xFF008B62),
                     child: Text(
                       record.camelNo,
                       style: const TextStyle(
                         color: Colors.white,
                         fontWeight: FontWeight.bold,
                       ),
                     ),
                   ),
                   const SizedBox(width: 10),
                   Expanded(
                     child: Text(
                       record.camelName,
                       maxLines: 1,
                       overflow: TextOverflow.ellipsis,
                       style: const TextStyle(
                         color: Color(0xFF062C5E),
                         fontWeight: FontWeight.bold,
                         fontSize: 16,
                       ),
                     ),
                   ),
                   IconButton(
                     onPressed: () {
                       copySelectedGps(context);
                     },
                     icon: const Icon(Icons.copy_rounded),
                     tooltip: 'کپی مختصات',
                   ),
                   IconButton(
                     onPressed: () {
                       Navigator.of(context).push(
                         MaterialPageRoute(
                           builder: (_) =>_MapTagDetailPage(record: record)
                         ),
                       );
                     },
                     icon: const Icon(Icons.open_in_new_rounded),
                     tooltip: 'جزئیات تگ',
                   ),
                 ],
               ),
              if (showSelectedCamelPhoto) ...[
                const SizedBox(height: 10),

                Container(
                  width: double.infinity,
                  height: 150,
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.92),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: const Color(0xFFC8EBDD),
                    ),
                  ),
                  clipBehavior: Clip.antiAlias,

                  child: isLoadingSelectedCamelDetail
                      ? const Center(
                          child: CircularProgressIndicator(),
                        )
                      : selectedPhotoPath.isNotEmpty &&
                              File(selectedPhotoPath).existsSync()
                          ? Image.file(
                              File(selectedPhotoPath),
                              fit: BoxFit.cover,
                            )
                          : Center(
                              child: Text(
                                selectedCamelPhotoError ??
                                    'عکس شتر پیدا نشد.',
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  color: Colors.black54,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                ),
              ],
               const SizedBox(height: 8),
               Directionality(
                 textDirection: TextDirection.ltr,
                 child: Text(
                   gpsText,
                   maxLines: 1,
                   overflow: TextOverflow.ellipsis,
                   style: const TextStyle(
                     color: Color(0xFF008B62),
                     fontWeight: FontWeight.bold,
                     fontSize: 12,
                   ),
                 ),
               ),
               const SizedBox(height: 6),
               Text(
                 '${record.locationName} / باتری: ${record.batteryText}',
                 maxLines: 1,
                 overflow: TextOverflow.ellipsis,
                 style: const TextStyle(
                   color: Colors.black54,
                   fontSize: 12,
                 ),
               ),
               const SizedBox(height: 10),

               if (routeRecord?.tagId == record.tagId)
                 SizedBox(
                   width: double.infinity,
                   height: 42,
                   child: OutlinedButton.icon(
                     onPressed: () { clearRouteMode(); widget.onRouteClosed?.call(); },
                     icon: const Icon(Icons.close_rounded),
                     label: Text(
                       'بستن مسیر (${routeRecords.length} نقطه)',
                     ),
                   ),
                 )
               else
                 SizedBox(
                   width: double.infinity,
                   height: 42,
                   child: ElevatedButton.icon(
                     onPressed: () {
                       showRouteForRecord(record);
                     },
                     icon: const Icon(Icons.route_rounded),
                     label: const Text('نمایش مسیر امروز'),
                     style: ElevatedButton.styleFrom(
                       backgroundColor: const Color(0xFF008B62),
                       foregroundColor: Colors.white,
                     ),
                   ),
                 ),
             ],
           ),
         );
       }

       Widget buildZoomChip(TagRecord record) {
         final isSelected =
             selectedRecord != null && isSameRecord(selectedRecord!, record);

         return Padding(
           padding: const EdgeInsets.only(left: 8),
           child: ChoiceChip(
             selected: isSelected,
             avatar: CircleAvatar(
               backgroundColor:
                   isSelected ? const Color(0xFF062C5E) : const Color(0xFFF3E8D6),
               child: Text(
                 record.camelNo,
                 style: TextStyle(
                   color: isSelected ? Colors.white : const Color(0xFF062C5E),
                   fontSize: 10,
                   fontWeight: FontWeight.bold,
                 ),
               ),
             ),
             label: Text(
               record.camelName,
               maxLines: 1,
               overflow: TextOverflow.ellipsis,
             ),
            onSelected: (_) {
              zoomToRecord(
                record,
                showPhoto: true,
              );
            },
           ),
         );
       }

       @override
       Widget build(BuildContext context) {
     if (mapRecords.isEmpty &&
         activeZones.isEmpty &&
         activePolygonZones.isEmpty &&
         widget.area == null) {
       return const SizedBox.shrink();
     }

         return Column(
           children: [
             if (widget.showQuickSelector) SingleChildScrollView(
               scrollDirection: Axis.horizontal,
               child: Row(
                 children: [
                   OutlinedButton.icon(
                     onPressed: () {
                       fitAll(viewportSize);
                     },
                     icon: const Icon(Icons.center_focus_strong_rounded),
                     label: const Text('نمای همه'),
                   ),
                   const SizedBox(width: 8),
                   ...mapRecords.map(buildZoomChip),
                 ],
               ),
             ),
             const SizedBox(height: 10),
             SizedBox(
             height: widget.height,
               width: double.infinity,
               child: LayoutBuilder(
                 builder: (context, constraints) {
                   viewportSize = Size(
                     constraints.maxWidth,
                     constraints.maxHeight,
                   );

                   scheduleFitAll(viewportSize);

                   return Stack(
                     children: [
                       Container(
                         decoration: BoxDecoration(
                           color: const Color(0xFFEAF2FF),
                           borderRadius: BorderRadius.circular(18),
                           border: Border.all(
                             color: const Color(0xFFD3E2F7),
                           ),
                         ),
                         clipBehavior: Clip.hardEdge,
                         child: InteractiveViewer(
                           transformationController: transformationController,
                           minScale: 0.25,
                           maxScale: 6,
                           boundaryMargin: const EdgeInsets.all(900),
                           constrained: false,
                           child: SizedBox(
                             width: sceneWidth,
                             height: sceneHeight,
                             child: Stack(
                               clipBehavior: Clip.none,
                              children: [
                                Positioned.fill(
                                   child: CustomPaint(
                                     painter: _MapGridOnlyPainter(),
                                   ),
                                 ),

                                buildSelectedAreaShape(),

                                ...activePolygonZones.map(buildPolygonZoneShape),

                                ...activePolygonZones.map(buildPolygonZoneLabel),

                                ...activeZones.map(buildZoneShape),

                                ...activeZones.map(buildAreaZoneLabel),

                                if (routeRecords.isNotEmpty)
                                  Positioned.fill(
                                    child: IgnorePointer(
                                      child: CustomPaint(
                                       painter: _CamelRoutePainter(
                                         points: routeRecords
                                             .where((record) {
                                               return record.latitude != null &&
                                                   record.longitude != null;
                                             })
                                             .map(positionFor)
                                             .toList(),
                                         mapScale: safeMapScale,
                                       ),
                                      ),
                                    ),
                                  ),

                              if (isRouteMode)
                                ...visibleMapRecords.map(
                                  buildTagMarker,
                                )
                              else if (showClusters)
                                ...camelClusters.map(
                                  buildClusterMarker,
                                )
                              else
                                ...visibleMapRecords.map(
                                  buildTagMarker,
                                ),
                              ],
                             ),
                           ),
                         ),
                       ),
                       Positioned(
                         top: 10,
                         right: 10,
                         child: Container(
                           padding: const EdgeInsets.symmetric(
                             horizontal: 9,
                             vertical: 6,
                           ),
                           decoration: BoxDecoration(
                             color: Colors.white.withValues(alpha: 0.92),
                             borderRadius: BorderRadius.circular(12),
                           ),
                           child: Text(
                            isRouteMode
                                ? 'مسیر ${routeRecord!.camelName} • ${routeRecords.length} نقطه'
                                : '${mapRecords.length} شتر • ${activePolygonZones.length} محدوده داخلی',
                             style: const TextStyle(
                               color: Color(0xFF062C5E),
                               fontWeight: FontWeight.bold,
                               fontSize: 12,
                             ),
                           ),
                         ),
                       ),


                       buildRouteStatusBar(),


                       Positioned(
                         top: 10,
                         left: 10,
                         child: Column(
                           children: [
                             _MapControlButton(
                               icon: Icons.add_rounded,
                               onTap: () {
                                 changeZoom(1.25);
                               },
                             ),
                             const SizedBox(height: 6),
                             _MapControlButton(
                               icon: Icons.remove_rounded,
                               onTap: () {
                                 changeZoom(0.8);
                               },
                             ),
                             const SizedBox(height: 6),
                             _MapControlButton(
                               icon: Icons.center_focus_strong_rounded,
                               onTap: () {
                                 fitAll(viewportSize);
                               },
                             ),
                           ],
                         ),
                       ),
                       const Positioned(
                         bottom: 10,
                         left: 10,
                         child: Text(
                           'با دو انگشت زوم کن / روی تگ بزن',
                           style: TextStyle(
                             color: Colors.black45,
                             fontWeight: FontWeight.bold,
                             fontSize: 11,
                           ),
                         ),
                       ),
                     ],
                   );
                 },
               ),
             ),
             const SizedBox(height: 10),
             buildSelectedRecordPanel(context),
           ],
         );
       }
     }

     class _GpsBounds {
       final double minLat;
       final double maxLat;
       final double minLng;
       final double maxLng;

       const _GpsBounds({
         required this.minLat,
         required this.maxLat,
         required this.minLng,
         required this.maxLng,
       });

       double get latRange {
         final value = maxLat - minLat;
         if (value.abs() < 0.000001) return 0.000001;
         return value;
       }

       double get lngRange {
         final value = maxLng - minLng;
         if (value.abs() < 0.000001) return 0.000001;
         return value;
       }

       _GpsBounds withPadding(double percent) {
         final latPad = latRange * percent;
         final lngPad = lngRange * percent;

         return _GpsBounds(
           minLat: minLat - latPad,
           maxLat: maxLat + latPad,
           minLng: minLng - lngPad,
           maxLng: maxLng + lngPad,
         );
       }
     }

     class _GpsPoint {
       final double latitude;
       final double longitude;

       const _GpsPoint({
         required this.latitude,
         required this.longitude,
       });
     }

     class _MapControlButton extends StatelessWidget {

       final IconData icon;
       final VoidCallback onTap;


       const _MapControlButton({
         required this.icon,
         required this.onTap,
       });


       @override
       Widget build(BuildContext context) {

         return GestureDetector(

           onTap: onTap,

           child: Container(

             width: 46,
             height: 46,


             decoration: BoxDecoration(

               color: Colors.white.withValues(alpha: 0.92),

               borderRadius:
                   BorderRadius.circular(16),


               boxShadow: [

                 BoxShadow(

                   color:
                       Colors.black.withValues(alpha: 0.12),

                   blurRadius: 14,

                   offset:
                       const Offset(0,4),
                 )

               ],
             ),


             child: Icon(
               icon,
               color:
                   const Color(0xFF062C5E),
               size:22,
             ),

           ),

         );
       }
     }

    class _PolygonZonePainter extends CustomPainter {
      final List<Offset> offsets;
      final List<List<Offset>> holeOffsets;
      final Color color;


      const _PolygonZonePainter({
        required this.offsets,
        this.holeOffsets = const [],
        required this.color,
      });

      @override
      void paint(
        Canvas canvas,
        Size size,
      ) {
        if (offsets.length < 3) {
          return;
        }

        final path = Path()
          ..moveTo(
            offsets.first.dx,
            offsets.first.dy,
          );

        for (int i = 1; i < offsets.length; i++) {
          path.lineTo(
            offsets[i].dx,
            offsets[i].dy,
          );
        }

        path.close();
        path.fillType = PathFillType.evenOdd;
        for (final hole in holeOffsets) {
          if (hole.length < 3) continue;
          path.moveTo(hole.first.dx, hole.first.dy);
          for (var i = 1; i < hole.length; i++) {
            path.lineTo(hole[i].dx, hole[i].dy);
          }
          path.close();
        }


        final fillPaint = Paint()
          ..color = color.withValues(alpha: 0.075)
          ..style = PaintingStyle.fill;


        final borderPaint = Paint()
          ..color = color.withValues(alpha: 0.70)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.6;


        canvas.drawPath(
          path,
          fillPaint,
        );

        canvas.drawPath(
          path,
          borderPaint,
        );


        for (final point in offsets) {

          canvas.drawCircle(
            point,
            2.6,
            Paint()
              ..color = Colors.white
              ..style = PaintingStyle.fill,
          );


          canvas.drawCircle(
            point,
            2.6,
            Paint()
              ..color = color.withValues(alpha: 0.85)
              ..style = PaintingStyle.stroke
              ..strokeWidth = 1.2,
          );
        }

      }





     @override
     bool shouldRepaint(
       covariant _PolygonZonePainter oldDelegate,
     ) {

       return oldDelegate.offsets != offsets ||
           oldDelegate.holeOffsets != holeOffsets ||
           oldDelegate.color != color;

     }
    }



class _MapGridOnlyPainter extends CustomPainter {


  @override
  void paint(
    Canvas canvas,
    Size size,
  ) {


    // رنگ پایه خاکی نقشه

    final backgroundPaint =
        Paint()
          ..color =
              const Color(0xFFF4F1E8)
          ..style =
              PaintingStyle.fill;


    canvas.drawRect(
      Offset.zero & size,
      backgroundPaint,
    );



    // خطوط خیلی نرم مسیر

    final roadPaint =
        Paint()
          ..color =
              const Color(0xFFD8D2C3)
          ..strokeWidth = 1
          ..style =
              PaintingStyle.stroke;



    const step = 90.0;



    for (
      double x = 0;
      x < size.width;
      x += step
    ) {

      canvas.drawLine(
        Offset(x,0),
        Offset(
          x,
          size.height,
        ),
        roadPaint,
      );

    }



    for (
      double y = 0;
      y < size.height;
      y += step
    ) {

      canvas.drawLine(
        Offset(0,y),
        Offset(
          size.width,
          y,
        ),
        roadPaint,
      );

    }




    // چند مسیر منحنی تزئینی

    final pathPaint =
        Paint()
          ..color =
              const Color(0xFFC8C0AF)
          ..strokeWidth = 2
          ..style =
              PaintingStyle.stroke;


    final path = Path();


    path.moveTo(
      0,
      size.height * 0.65,
    );


    path.quadraticBezierTo(
      size.width * 0.35,
      size.height * 0.45,
      size.width,
      size.height * 0.55,
    );


    canvas.drawPath(
      path,
      pathPaint,
    );

  }



  @override
  bool shouldRepaint(
    covariant CustomPainter oldDelegate,
  ) {

    return false;

  }

}


class GpsRecordCard extends StatelessWidget {
 final TagRecord record;
 final String dateText;
 final List<AreaZone> zones;
 final List<PolygonZone> polygonZones;



 const GpsRecordCard({
   super.key,
   required this.record,
   required this.dateText,
   this.zones = const [],
   this.polygonZones = const [],
 });

  bool get hasGps {
    return record.latitude != null && record.longitude != null;
  }

  ZoneCheckResult? get zoneResult {
    if (!hasGps || zones.isEmpty) {
      return null;
    }

    return ZoneCheckService.checkRecord(
      record: record,
      zones: zones,
    );
  }



    List<PolygonZone> get activePolygonZones {
      return polygonZones.where((zone) {
        return zone.isActive && zone.isValid;
      }).toList();
    }

    bool isPointInsidePolygonZone({
      required double latitude,
      required double longitude,
      required PolygonZone zone,
    }) {
      final points = zone.points;

      if (points.length < 3) {
        return false;
      }

      bool inside = false;
      int j = points.length - 1;

      for (int i = 0; i < points.length; i++) {
        final xi = points[i].longitude;
        final yi = points[i].latitude;

        final xj = points[j].longitude;
        final yj = points[j].latitude;

        final intersects =
            ((yi > latitude) != (yj > latitude)) &&
            (longitude <
                (xj - xi) *
                        (latitude - yi) /
                        ((yj - yi) == 0 ? 0.0000001 : (yj - yi)) +
                    xi);

        if (intersects) {
          inside = !inside;
        }

        j = i;
      }

      return inside;
    }

    List<PolygonZone> get containingPolygonZones {
      if (!hasGps) {
        return [];
      }

      return activePolygonZones.where((zone) {
        return isPointInsidePolygonZone(
          latitude: record.latitude!,
          longitude: record.longitude!,
          zone: zone,
        );
      }).toList();
    }

    bool get isInsideForbiddenPolygon {
      return containingPolygonZones.any((zone) {
        return zone.type == PolygonZoneType.forbidden;
      });
    }

    bool get isInsideAllowedPolygon {
      return containingPolygonZones.any((zone) {
        return zone.type != PolygonZoneType.forbidden;
      });
    }

    String get containingPolygonNames {
      return containingPolygonZones.map((zone) => zone.name).join('، ');
    }

    bool get hasAnyZoneDefinition {
      return zones.isNotEmpty || activePolygonZones.isNotEmpty;
    }


  Future<void> copyGps(BuildContext context) async {
    if (!hasGps) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('برای این رکورد GPS ثبت نشده است.'),
        ),
      );
      return;
    }

    final text =
        '${record.latitude!.toStringAsFixed(6)},${record.longitude!.toStringAsFixed(6)}';

    await Clipboard.setData(
      ClipboardData(text: text),
    );

    if (!context.mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('مختصات GPS کپی شد.'),
      ),
    );
  }

  String get gpsText {
    if (!hasGps) return 'GPS ثبت نشده';

    return '${record.latitude!.toStringAsFixed(5)}, ${record.longitude!.toStringAsFixed(5)}';
  }

  Color get mainStatusColor {
    final result = zoneResult;

     if (isInsideForbiddenPolygon) {
        return const Color(0xFFD32F2F);
      }

      if (isInsideAllowedPolygon) {
        return const Color(0xFF008B62);
      }

    if (record.lock == 0) {
      return const Color(0xFFD32F2F);
    }

    if (result?.isInsideForbiddenZone == true) {
      return const Color(0xFFD32F2F);
    }

    if (result?.isOutsideAllowedZones == true) {
      return const Color(0xFFE87500);
    }

    if (record.isBatteryLow) {
      return const Color(0xFFE87500);
    }

    return const Color(0xFF008B62);
  }

  IconData get mainStatusIcon {
    final result = zoneResult;

    if (record.lock == 0) {
      return Icons.lock_open_rounded;
    }

    if (result?.isInsideForbiddenZone == true) {
      return Icons.block_rounded;
    }

    if (result?.isOutsideAllowedZones == true) {
      return Icons.warning_rounded;
    }

    return Icons.gps_fixed_rounded;
  }

 String zoneStatusText(ZoneCheckResult? result) {
   if (!hasGps) return 'GPS برای این تگ ثبت نشده است.';
   return MapHerdStatus.assess(record, null, zones, polygonZones).description;
 }

  Color zoneStatusColor(ZoneCheckResult? result) {
    if (!hasGps) {
      return Colors.grey;
    }

    if (isInsideForbiddenPolygon) {
      return const Color(0xFFD32F2F);
    }

    if (isInsideAllowedPolygon) {
      return const Color(0xFF008B62);
    }

   if (!hasAnyZoneDefinition) {
     return const Color(0xFF086EBB);
   }

    if (result?.isInsideForbiddenZone == true) {
      return const Color(0xFFD32F2F);
    }

    if (result?.isOutsideAllowedZones == true) {
      return const Color(0xFFE87500);
    }

    if (result?.insideZones.isNotEmpty == true) {
      return const Color(0xFF008B62);
    }

    return Colors.grey;
  }

  IconData zoneStatusIcon(ZoneCheckResult? result) {
    if (!hasGps) {
      return Icons.gps_off_rounded;
    }

    if (isInsideForbiddenPolygon) {
      return Icons.block_rounded;
    }

    if (isInsideAllowedPolygon) {
      return Icons.check_circle_rounded;
    }

  if (!hasAnyZoneDefinition) {
    return Icons.layers_clear_rounded;
  }

    if (result?.isInsideForbiddenZone == true) {
      return Icons.block_rounded;
    }

    if (result?.isOutsideAllowedZones == true) {
      return Icons.warning_rounded;
    }

    if (result?.insideZones.isNotEmpty == true) {
      return Icons.check_circle_rounded;
    }

    return Icons.help_outline_rounded;
  }

  @override
  Widget build(BuildContext context) {
    final result = zoneResult;
    final isLowBattery = record.isBatteryLow;
    final isUnlocked = record.lock == 0;

    final zoneColor = zoneStatusColor(result);

    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: () {
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => _MapTagDetailPage(record: record)
          ),
        );
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: mainStatusColor.withValues(alpha: 0.22),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.06),
              blurRadius: 12,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Column(
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 24,
                  backgroundColor: mainStatusColor.withValues(alpha: 0.12),
                  child: Text(
                    record.camelNo,
                    style: TextStyle(
                      color: mainStatusColor,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        record.camelName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Directionality(
                        textDirection: TextDirection.ltr,
                        child: Text(
                          record.tagId,
                          style: const TextStyle(
                            color: Colors.black54,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: mainStatusColor.withValues(alpha: 0.10),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    mainStatusIcon,
                    color: mainStatusColor,
                    size: 22,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 12),

            Row(
              children: [
                Expanded(
                  child: _GpsCardMiniBadge(
                    icon: Icons.battery_full_rounded,
                    text: record.batteryText,
                    color: isLowBattery
                        ? const Color(0xFFD32F2F)
                        : const Color(0xFF008B62),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _GpsCardMiniBadge(
                    icon: isUnlocked
                        ? Icons.lock_open_rounded
                        : Icons.lock_rounded,
                    text: record.lockText,
                    color: isUnlocked
                        ? const Color(0xFFD32F2F)
                        : const Color(0xFF008B62),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 10),

            Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 10,
                vertical: 9,
              ),
              decoration: BoxDecoration(
                color: hasGps
                    ? const Color(0xFFEAF8F2)
                    : const Color(0xFFFFF3E0),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  Icon(
                    hasGps
                        ? Icons.my_location_rounded
                        : Icons.gps_not_fixed_rounded,
                    size: 18,
                    color: hasGps
                        ? const Color(0xFF008B62)
                        : const Color(0xFFE87500),
                  ),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Directionality(
                      textDirection: TextDirection.ltr,
                      child: Text(
                        gpsText,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: hasGps
                              ? const Color(0xFF008B62)
                              : const Color(0xFFE87500),
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ),
                  TextButton.icon(
                    onPressed: hasGps
                        ? () {
                            copyGps(context);
                          }
                        : null,
                    icon: const Icon(Icons.copy_rounded, size: 16),
                    label: const Text(
                      'کپی',
                      style: TextStyle(fontSize: 11),
                    ),
                    style: TextButton.styleFrom(
                      padding: const EdgeInsets.symmetric(horizontal: 6),
                      minimumSize: const Size(0, 30),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 8),

            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(
                horizontal: 10,
                vertical: 10,
              ),
              decoration: BoxDecoration(
                color: zoneColor.withValues(alpha: 0.10),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: zoneColor.withValues(alpha: 0.20),
                ),
              ),
              child: Row(
                children: [
                  Icon(
                    zoneStatusIcon(result),
                    color: zoneColor,
                    size: 19,
                  ),
                  const SizedBox(width: 7),
                  Expanded(
                    child: Text(
                      zoneStatusText(result),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: zoneColor,
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                        height: 1.5,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 8),

            Row(
              children: [
                Expanded(
                  child: Text(
                    record.locationName,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Colors.black54,
                      fontSize: 12,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  dateText,
                  style: const TextStyle(
                    color: Colors.black45,
                    fontWeight: FontWeight.bold,
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}





class _CamelRoutePainter extends CustomPainter {
  final List<Offset> points;
  final double mapScale;

  const _CamelRoutePainter({
    required this.points,
    required this.mapScale,
  });

  double sceneSize(double screenSize) {
    final safeScale = mapScale <= 0 ? 1.0 : mapScale;
    return screenSize / safeScale;
  }

  @override
  void paint(Canvas canvas, Size size) {
    if (points.isEmpty) {
      return;
    }

    if (points.length >= 2) {
      final path = Path()
        ..moveTo(
          points.first.dx,
          points.first.dy,
        );

      for (final point in points.skip(1)) {
        path.lineTo(
          point.dx,
          point.dy,
        );
      }

      final shadowPaint = Paint()
        ..color = Colors.white.withValues(alpha: 0.82)
        ..strokeWidth = sceneSize(5)
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round
        ..style = PaintingStyle.stroke;

      final routePaint = Paint()
        ..color = const Color(0xFF008B62)
        ..strokeWidth = sceneSize(2.4)
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round
        ..style = PaintingStyle.stroke;

      canvas.drawPath(path, shadowPaint);
      canvas.drawPath(path, routePaint);

      drawDirectionArrows(canvas);
    }

    drawMiddlePoints(canvas);
    drawStartAndEnd(canvas);
  }

  void drawMiddlePoints(Canvas canvas) {
    if (points.length <= 2) {
      return;
    }

    final pointPaint = Paint()
      ..color = const Color(0xFF008B62).withValues(alpha: 0.70)
      ..style = PaintingStyle.fill;

    for (final point in points.skip(1).take(points.length - 2)) {
      canvas.drawCircle(
        point,
        sceneSize(1.6),
        pointPaint,
      );
    }
  }

  void drawStartAndEnd(Canvas canvas) {
    final start = points.first;
    final end = points.last;

    canvas.drawCircle(
      start,
      sceneSize(5),
      Paint()..color = Colors.white,
    );

    canvas.drawCircle(
      start,
      sceneSize(3.3),
      Paint()..color = const Color(0xFF008B62),
    );

    canvas.drawCircle(
      end,
      sceneSize(5.5),
      Paint()..color = Colors.white,
    );

    canvas.drawCircle(
      end,
      sceneSize(3.7),
      Paint()..color = const Color(0xFFD32F2F),
    );

    drawPointLabel(
      canvas: canvas,
      point: start,
      text: 'شروع',
      color: const Color(0xFF008B62),
      dy: sceneSize(-18),
    );

    drawPointLabel(
      canvas: canvas,
      point: end,
      text: 'پایان',
      color: const Color(0xFFD32F2F),
      dy: sceneSize(8),
    );
  }

  void drawPointLabel({
    required Canvas canvas,
    required Offset point,
    required String text,
    required Color color,
    required double dy,
  }) {
    final textPainter = TextPainter(
      text: TextSpan(
        text: text,
        style: TextStyle(
          color: color,
          fontSize: sceneSize(7),
          fontWeight: FontWeight.bold,
        ),
      ),
      textDirection: TextDirection.rtl,
    );

    textPainter.layout();

    final horizontalPadding = sceneSize(4);
    final verticalPadding = sceneSize(2);

    final rect = Rect.fromLTWH(
      point.dx - textPainter.width / 2 - horizontalPadding,
      point.dy + dy,
      textPainter.width + horizontalPadding * 2,
      textPainter.height + verticalPadding * 2,
    );

    final rrect = RRect.fromRectAndRadius(
      rect,
      Radius.circular(sceneSize(5)),
    );

    canvas.drawRRect(
      rrect,
      Paint()..color = Colors.white.withValues(alpha: 0.88),
    );

    canvas.drawRRect(
      rrect,
      Paint()
        ..color = color.withValues(alpha: 0.30)
        ..style = PaintingStyle.stroke
        ..strokeWidth = sceneSize(0.8),
    );

    textPainter.paint(
      canvas,
      Offset(
        rect.left + horizontalPadding,
        rect.top + verticalPadding,
      ),
    );
  }

  void drawDirectionArrows(Canvas canvas) {
    if (points.length < 2) {
      return;
    }

    final minDistance = sceneSize(180);

    double accumulatedDistance = 0;

    for (int i = 1; i < points.length; i++) {
      final from = points[i - 1];
      final to = points[i];

      final distance = (to - from).distance;
      accumulatedDistance += distance;

      if (accumulatedDistance < minDistance) {
        continue;
      }

      if (distance < sceneSize(18)) {
        continue;
      }

      drawArrow(
        canvas: canvas,
        from: from,
        to: to,
      );

      accumulatedDistance = 0;
    }
  }

  void drawArrow({
    required Canvas canvas,
    required Offset from,
    required Offset to,
  }) {
    final angle = math.atan2(
      to.dy - from.dy,
      to.dx - from.dx,
    );

    final center = Offset(
      (from.dx + to.dx) / 2,
      (from.dy + to.dy) / 2,
    );

    final arrowSize = sceneSize(5.5);

    final arrowPath = Path()
      ..moveTo(arrowSize, 0)
      ..lineTo(-arrowSize * 0.55, -arrowSize * 0.50)
      ..lineTo(-arrowSize * 0.25, 0)
      ..lineTo(-arrowSize * 0.55, arrowSize * 0.50)
      ..close();

    canvas.save();

    canvas.translate(
      center.dx,
      center.dy,
    );

    canvas.rotate(angle);

    canvas.drawPath(
      arrowPath,
      Paint()
        ..color = Colors.white.withValues(alpha: 0.90)
        ..style = PaintingStyle.fill,
    );

    canvas.drawPath(
      arrowPath,
      Paint()
        ..color = const Color(0xFF008B62)
        ..style = PaintingStyle.stroke
        ..strokeWidth = sceneSize(0.9),
    );

    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _CamelRoutePainter oldDelegate) {
    return oldDelegate.points != points ||
        oldDelegate.mapScale != mapScale;
  }
}




class _GpsCardMiniBadge extends StatelessWidget {
  final IconData icon;
  final String text;
  final Color color;

  const _GpsCardMiniBadge({
    required this.icon,
    required this.text,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 9,
        vertical: 8,
      ),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.09),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Icon(
            icon,
            color: color,
            size: 17,
          ),
          const SizedBox(width: 5),
          Expanded(
            child: Text(
              text,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: color,
                fontWeight: FontWeight.bold,
                fontSize: 11,
              ),
            ),
          ),
        ],
      ),
    );
  }
}




class AreaZonesPage extends StatefulWidget {
  const AreaZonesPage({super.key});

  @override
  State<AreaZonesPage> createState() => _AreaZonesPageState();
}

class _AreaZonesPageState extends State<AreaZonesPage> {
  bool isLoading = true;
  List<AreaZone> zones = [];

  @override
  void initState() {
    super.initState();
    loadZones();
  }

  Future<void> loadZones() async {
    final loadedZones = await AreaZoneService.loadZones();

    if (!mounted) return;

    setState(() {
      zones = loadedZones;
      isLoading = false;
    });
  }

  Color zoneColor(AreaZoneType type) {
    switch (type) {
      case AreaZoneType.stable:
        return const Color(0xFF7B3FB3);
      case AreaZoneType.pasture:
        return const Color(0xFF008B62);
      case AreaZoneType.water:
        return const Color(0xFF086EBB);
      case AreaZoneType.route:
        return const Color(0xFFE87500);
      case AreaZoneType.forbidden:
        return const Color(0xFFD32F2F);
    }
  }

  String zoneTypeText(AreaZoneType type) {
    switch (type) {
      case AreaZoneType.stable:
        return 'آغل';
      case AreaZoneType.pasture:
        return 'چراگاه';
      case AreaZoneType.water:
        return 'آبشخور';
      case AreaZoneType.route:
        return 'مسیر';
      case AreaZoneType.forbidden:
        return 'منطقه ممنوع';
    }
  }

  Future<void> showAddZoneDialog() async {
    final nameController = TextEditingController();
    final radiusController = TextEditingController(text: '300');

    AreaZoneType selectedType = AreaZoneType.pasture;
    bool isSaving = false;

    await showDialog(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return Directionality(
              textDirection: TextDirection.rtl,
              child: AlertDialog(
                title: const Text('تعریف محدوده جدید'),
                content: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text(
                        'مرکز محدوده از GPS فعلی گوشی گرفته می‌شود. برای تعریف محدوده، داخل همان محل بایست و دکمه ذخیره را بزن.',
                        style: TextStyle(
                          color: Colors.black54,
                          height: 1.7,
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: nameController,
                        decoration: const InputDecoration(
                          labelText: 'نام محدوده',
                          hintText: 'مثلاً آغل اصلی',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 12),
                      DropdownButtonFormField<AreaZoneType>(
                        value: selectedType,
                        decoration: const InputDecoration(
                          labelText: 'نوع محدوده',
                          border: OutlineInputBorder(),
                        ),
                        items: AreaZoneType.values.map((type) {
                          return DropdownMenuItem(
                            value: type,
                            child: Text(zoneTypeText(type)),
                          );
                        }).toList(),
                        onChanged: isSaving
                            ? null
                            : (value) {
                                if (value == null) return;

                                setDialogState(() {
                                  selectedType = value;
                                });
                              },
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: radiusController,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(
                          labelText: 'شعاع محدوده بر حسب متر',
                          hintText: 'مثلاً 300',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      if (isSaving) ...[
                        const SizedBox(height: 14),
                        const LinearProgressIndicator(),
                        const SizedBox(height: 8),
                        const Text(
                          'در حال دریافت GPS و ذخیره محدوده...',
                          style: TextStyle(color: Colors.black54),
                        ),
                      ],
                    ],
                  ),
                ),
                actions: [
                  TextButton(
                    onPressed: isSaving
                        ? null
                        : () {
                            Navigator.of(dialogContext).pop();
                          },
                    child: const Text('انصراف'),
                  ),
                  ElevatedButton.icon(
                    onPressed: isSaving
                        ? null
                        : () async {
                            final name = nameController.text.trim();
                            final radiusText = radiusController.text.trim();
                            final radius = double.tryParse(radiusText);

                            if (name.isEmpty) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('نام محدوده را وارد کن.'),
                                ),
                              );
                              return;
                            }

                            if (radius == null || radius <= 0) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('شعاع محدوده معتبر نیست.'),
                                ),
                              );
                              return;
                            }

                            setDialogState(() {
                              isSaving = true;
                            });

                            final locationResult =
                                await LocationService.getCurrentLocation();

                            if (!locationResult.success ||
                                locationResult.latitude == null ||
                                locationResult.longitude == null) {
                              setDialogState(() {
                                isSaving = false;
                              });

                              if (!mounted) return;

                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text(locationResult.message),
                                ),
                              );
                              return;
                            }

                            final now = DateTime.now();

                            final zone = AreaZone(
                              id: 'zone-${now.millisecondsSinceEpoch}',
                              name: name,
                              type: selectedType,
                              centerLatitude: locationResult.latitude!,
                              centerLongitude: locationResult.longitude!,
                              radiusMeters: radius,
                              isActive: true,
                              createdAt: now.toIso8601String(),
                            );

                            await AreaZoneService.addZone(zone);

                            if (!mounted) return;

                            Navigator.of(dialogContext).pop();

                            await loadZones();

                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text('محدوده جدید ذخیره شد.'),
                              ),
                            );
                          },
                    icon: const Icon(Icons.save_rounded),
                    label: const Text('ذخیره محدوده'),
                  ),
                ],
              ),
            );
          },
        );
      },
    );

    nameController.dispose();
    radiusController.dispose();
  }

  Future<void> deleteZone(AreaZone zone) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: AlertDialog(
            title: const Text('حذف محدوده'),
            content: Text('آیا محدوده «${zone.name}» حذف شود؟'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop(false);
                },
                child: const Text('انصراف'),
              ),
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.of(context).pop(true);
                },
                icon: const Icon(Icons.delete_rounded),
                label: const Text('حذف'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red,
                  foregroundColor: Colors.white,
                ),
              ),
            ],
          ),
        );
      },
    );

    if (confirm != true) return;

    await AreaZoneService.deleteZone(zone.id);

    await loadZones();

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('محدوده حذف شد.'),
      ),
    );
  }

  Future<void> toggleZone(AreaZone zone) async {
    final updatedZone = zone.copyWith(
      isActive: !zone.isActive,
    );

    await AreaZoneService.updateZone(updatedZone);

    await loadZones();
  }

  @override
  Widget build(BuildContext context) {
    final activeCount = zones.where((zone) => zone.isActive).length;
    final forbiddenCount = zones
        .where((zone) => zone.type == AreaZoneType.forbidden)
        .length;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFFF5F7FA),
        appBar: AppBar(
          title: const Text('مدیریت محدوده‌ها'),
          centerTitle: true,
          backgroundColor: const Color(0xFF062C5E),
          foregroundColor: Colors.white,
          actions: [
            IconButton(
              onPressed: loadZones,
              icon: const Icon(Icons.refresh_rounded),
            ),
          ],
        ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: showAddZoneDialog,
          backgroundColor: const Color(0xFF008B62),
          foregroundColor: Colors.white,
          icon: const Icon(Icons.add_location_alt_rounded),
          label: const Text('محدوده جدید'),
        ),
        body: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 430),
            child: isLoading
                ? const Center(child: CircularProgressIndicator())
                : RefreshIndicator(
                    onRefresh: loadZones,
                    child: ListView(
                      padding: const EdgeInsets.all(14),
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: MapSummaryCard(
                                title: 'کل محدوده‌ها',
                                value: zones.length.toString(),
                                icon: Icons.layers_rounded,
                                color: const Color(0xFF086EBB),
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: MapSummaryCard(
                                title: 'فعال',
                                value: activeCount.toString(),
                                icon: Icons.check_circle_rounded,
                                color: const Color(0xFF008B62),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            Expanded(
                              child: MapSummaryCard(
                                title: 'ممنوعه',
                                value: forbiddenCount.toString(),
                                icon: Icons.block_rounded,
                                color: const Color(0xFFD32F2F),
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: MapSummaryCard(
                                title: 'GPS',
                                value: 'مرکز',
                                icon: Icons.gps_fixed_rounded,
                                color: const Color(0xFF7B3FB3),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 14),
                        Container(
                          padding: const EdgeInsets.all(14),
                          decoration: _mapCardDecoration(),
                          child: const Text(
                            'برای تعریف محدوده جدید، داخل محل موردنظر بایست و دکمه «محدوده جدید» را بزن. مرکز محدوده از GPS گوشی ذخیره می‌شود.',
                            style: TextStyle(
                              color: Colors.black54,
                              height: 1.7,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        const SizedBox(height: 14),
                        if (zones.isEmpty)
                          Container(
                            padding: const EdgeInsets.all(18),
                            decoration: _mapCardDecoration(),
                            child: const Column(
                              children: [
                                Icon(
                                  Icons.layers_clear_rounded,
                                  size: 54,
                                  color: Color(0xFF086EBB),
                                ),
                                SizedBox(height: 12),
                                Text(
                                  'هنوز محدوده‌ای تعریف نشده است.',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 17,
                                  ),
                                ),
                                SizedBox(height: 8),
                                Text(
                                  'با دکمه محدوده جدید، آغل، چراگاه، آبشخور یا منطقه ممنوع را ثبت کن.',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: Colors.black54,
                                    height: 1.7,
                                  ),
                                ),
                              ],
                            ),
                          )
                        else
                          ...zones.map(
                            (zone) => AreaZoneCard(
                              zone: zone,
                              color: zoneColor(zone.type),
                              onToggle: () {
                                toggleZone(zone);
                              },
                              onDelete: () {
                                deleteZone(zone);
                              },
                            ),
                          ),
                        const SizedBox(height: 90),
                      ],
                    ),
                  ),
          ),
        ),
      ),
    );
  }
}

class AreaZoneCard extends StatelessWidget {
  final AreaZone zone;
  final Color color;
  final VoidCallback onToggle;
  final VoidCallback onDelete;

  const AreaZoneCard({
    super.key,
    required this.zone,
    required this.color,
    required this.onToggle,
    required this.onDelete,
  });

  String get gpsText {
    return '${zone.centerLatitude.toStringAsFixed(6)}, ${zone.centerLongitude.toStringAsFixed(6)}';
  }

  IconData get zoneIcon {
    switch (zone.type) {
      case AreaZoneType.stable:
        return Icons.home_work_rounded;
      case AreaZoneType.pasture:
        return Icons.grass_rounded;
      case AreaZoneType.water:
        return Icons.water_drop_rounded;
      case AreaZoneType.route:
        return Icons.alt_route_rounded;
      case AreaZoneType.forbidden:
        return Icons.block_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: _mapCardDecoration(),
      child: Column(
        children: [
          Row(
            children: [
              CircleAvatar(
                backgroundColor: color.withValues(alpha: 0.12),
                child: Icon(
                  zoneIcon,
                  color: color,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      zone.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${zone.typeText} / شعاع ${zone.radiusMeters.toStringAsFixed(0)} متر',
                      style: TextStyle(
                        color: color,
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              Switch(
                value: zone.isActive,
                onChanged: (_) {
                  onToggle();
                },
              ),
            ],
          ),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 10,
              vertical: 9,
            ),
            decoration: BoxDecoration(
              color: const Color(0xFFF5F7FA),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                const Icon(
                  Icons.my_location_rounded,
                  size: 18,
                  color: Color(0xFF086EBB),
                ),
                const SizedBox(width: 6),
                Expanded(
                  child: Directionality(
                    textDirection: TextDirection.ltr,
                    child: Text(
                      gpsText,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Color(0xFF086EBB),
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                      ),
                    ),
                  ),
                ),
                IconButton(
                  onPressed: onDelete,
                  icon: const Icon(
                    Icons.delete_outline_rounded,
                    color: Colors.red,
                  ),
                  tooltip: 'حذف محدوده',
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}



class _MapTagDetailPage extends StatelessWidget {
  final TagRecord record;

  const _MapTagDetailPage({
    required this.record,
  });

  @override
  Widget build(BuildContext context) {
    final isLowBattery = record.isBatteryLow;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFFF5F7FA),
        appBar: AppBar(
          title: Text('جزئیات تگ ${record.tagId}'),
          centerTitle: true,
          backgroundColor: const Color(0xFF062C5E),
          foregroundColor: Colors.white,
        ),
        body: ListView(
          padding: const EdgeInsets.all(14),
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(18),
              decoration: _mapCardDecoration(),
              child: Column(
                children: [
                  CircleAvatar(
                    radius: 38,
                    backgroundColor: const Color(0xFFF3E8D6),
                    child: Text(
                      record.camelNo,
                      style: const TextStyle(
                        fontSize: 26,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),

                  const SizedBox(height: 12),

                  Text(
                    record.tagId,
                    textDirection: TextDirection.ltr,
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF062C5E),
                    ),
                  ),

                  const SizedBox(height: 6),

                  Text(
                    record.camelName,
                    style: const TextStyle(
                      color: Colors.black54,
                    ),
                  ),

                  const SizedBox(height: 16),

                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: isLowBattery
                          ? Colors.red.withValues(alpha: 0.10)
                          : Colors.green.withValues(alpha: 0.10),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      isLowBattery
                          ? 'نیازمند بررسی باتری'
                          : 'وضعیت عادی',
                      style: TextStyle(
                        color: isLowBattery
                            ? Colors.red
                            : Colors.green,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 14),

            Container(
              decoration: _mapCardDecoration(),
              child: Column(
                children: [
                  _MapDetailRow(
                    icon: Icons.battery_full_rounded,
                    title: 'وضعیت شارژ باتری',
                    value: record.batteryText,
                    valueColor: isLowBattery
                        ? Colors.red
                        : Colors.green,
                  ),

                  _MapDetailRow(
                    icon: Icons.access_time_rounded,
                    title: 'آخرین زمان دریافت',
                    value: record.receivedTime,
                  ),

                  _MapDetailRow(
                    icon: Icons.pets_rounded,
                    title: 'آخرین محل ثبت‌شده',
                    value: record.locationName,
                  ),

                  _MapDetailRow(
                    icon: Icons.network_check_rounded,
                    title: 'قدرت سیگنال',
                    value: '${record.signalPower} از ۵',
                  ),

                  if (record.state != null)
                    _MapDetailRow(
                      icon: Icons.sensors_rounded,
                      title: 'State خام دستگاه',
                      value: record.state.toString(),
                    ),

                  if (record.lock != null)
                    _MapDetailRow(
                      icon: Icons.lock_rounded,
                      title: 'وضعیت بسته بودن تگ',
                      value: record.lockText,
                    ),

                  if (record.counterLock != null)
                    _MapDetailRow(
                      icon: Icons.confirmation_number_rounded,
                      title: 'تعداد باز و بسته شدن تگ',
                      value: record.counterLock.toString(),
                    ),

                  if (record.count != null)
                    _MapDetailRow(
                      icon: Icons.numbers_rounded,
                      title: 'Count خام دستگاه',
                      value: record.count.toString(),
                    ),

                  _MapDetailRow(
                    icon: Icons.cloud_upload_rounded,
                    title: 'وضعیت ارسال',
                    value: record.sendStatusText,
                    valueColor: record.isGood
                        ? Colors.green
                        : Colors.orange,
                  ),

                  _MapDetailRow(
                    icon: Icons.my_location_rounded,
                    title: 'عرض جغرافیایی',
                    value: record.latitude == null
                        ? 'ثبت نشده'
                        : record.latitude!.toStringAsFixed(6),
                  ),

                  _MapDetailRow(
                    icon: Icons.explore_rounded,
                    title: 'طول جغرافیایی',
                    value: record.longitude == null
                        ? 'ثبت نشده'
                        : record.longitude!.toStringAsFixed(6),
                  ),

                  _MapDetailRow(
                    icon: Icons.gps_fixed_rounded,
                    title: 'دقت GPS',
                    value: record.accuracy == null
                        ? 'ثبت نشده'
                        : '${record.accuracy!.toStringAsFixed(1)} متر',
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MapDetailRow extends StatelessWidget {
  final IconData icon;
  final String title;
  final String value;
  final Color? valueColor;

  const _MapDetailRow({
    required this.icon,
    required this.title,
    required this.value,
    this.valueColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 14,
        vertical: 14,
      ),
      decoration: const BoxDecoration(
        border: Border(
          top: BorderSide(
            color: Color(0xFFE8EDF3),
          ),
        ),
      ),
      child: Row(
        children: [
          Icon(
            icon,
            color: const Color(0xFF062C5E),
          ),

          const SizedBox(width: 10),

          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
          ),

          Text(
            value,
            style: TextStyle(
              color: valueColor ?? Colors.black87,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}


