/// The "seen today" set is refreshed as tag messages are stored. Unseen is
/// fully reconciled against the registered herd only at the chosen interval.
/// In between, newly seen tags are removed from the previous unseen snapshot
/// immediately, so a camel is never shown in both sets at once.
class UnseenReconciliation {
  UnseenReconciliation({int intervalMinutes = 5})
      : _intervalMinutes = normalizeInterval(intervalMinutes);

  static const allowedIntervals = <int>[1, 2, 5, 10, 15, 30, 60];

  static int normalizeInterval(int value) =>
      allowedIntervals.contains(value) ? value : 5;

  int _intervalMinutes;
  int get intervalMinutes => _intervalMinutes;

  String? _dayKey;
  DateTime? _lastReconciledAt;
  final Set<String> _unseenTagIds = <String>{};

  DateTime? get nextReconcileAt => _lastReconciledAt == null
      ? null
      : _lastReconciledAt!.add(Duration(minutes: _intervalMinutes));

  int get unseenCount => _unseenTagIds.length;
  bool contains(String tagId) => _unseenTagIds.contains(tagId);

  void changeInterval(int minutes) {
    _intervalMinutes = normalizeInterval(minutes);
  }

  void update({
    required Iterable<String> registeredTags,
    required Iterable<String> seenTodayTags,
    required String dayKey,
    required DateTime now,
    bool force = false,
  }) {
    final all = registeredTags.toSet();
    final seen = seenTodayTags.toSet();
    final due = _lastReconciledAt == null ||
        _dayKey != dayKey ||
        now.isAfter(nextReconcileAt!) || now.isAtSameMomentAs(nextReconcileAt!);
    if (force || due) {
      _unseenTagIds
        ..clear()
        ..addAll(all.difference(seen));
      _lastReconciledAt = now;
      _dayKey = dayKey;
      return;
    }

    // Fast O(seen) reduction. A newly received tag cannot also remain unseen.
    _unseenTagIds.removeAll(seen);
    // If a camel was deleted, do not keep it in the previous snapshot.
    _unseenTagIds.retainAll(all);
    // Newly registered camels enter the unseen set on next reconciliation.
  }
}
