import 'dart:async';

import 'package:geolocator/geolocator.dart';

import 'location_service.dart';

/// A single phone GPS stream shared by the entire antenna connection.
/// Only fixes that existed at the instant a packet arrived can be attached to
/// that packet. GPS acquired later must never be backfilled onto old packets.
class PhoneGpsSession {
  PhoneGpsSession({this.onPosition});

  final void Function(AppLocationResult result)? onPosition;

  static const maxFixAge = Duration(seconds: 30);
  static const maxAccuracyMeters = 200.0;

  StreamSubscription<Position>? _positionSubscription;
  StreamSubscription<ServiceStatus>? _serviceSubscription;
  Timer? _recoveryTimer;
  Future<AppLocationResult>? _refreshInProgress;
  AppLocationResult? _latest;
  bool _watching = false;
  bool _openingStream = false;
  int _generation = 0;

  Future<AppLocationResult> refresh() {
    return _refreshInProgress ??= _refreshOnce().whenComplete(() {
      _refreshInProgress = null;
    });
  }

  Future<AppLocationResult> _refreshOnce() async {
    final generation = _generation;
    try {
      final result = await LocationService.getCurrentLocation();
      // An in-flight native read might finish AFTER disconnect or after
      // Android Location was switched off. Never cache that old result.
      if (generation != _generation ||
          !await Geolocator.isLocationServiceEnabled()) {
        _latest = null;
        return AppLocationResult.failed('GPS گوشی در دسترس نیست.');
      }
      _remember(result);
      return result;
    } catch (error) {
      final failed = AppLocationResult.failed('خطا در دریافت GPS گوشی: $error');
      onPosition?.call(failed);
      return failed;
    }
  }

  /// Start even when the phone's location switch is OFF. The service-status
  /// stream and recovery timer will acquire GPS when the user enables it.
  void startWatching() {
    if (_watching) return;
    _watching = true;
    final generation = ++_generation;

    _serviceSubscription = Geolocator.getServiceStatusStream().listen(
      (status) {
        if (!_watching || generation != _generation) return;
        if (status == ServiceStatus.disabled) {
          _latest = null; // Previously valid coordinates are now stale.
          final old = _positionSubscription;
          _positionSubscription = null;
          if (old != null) unawaited(old.cancel());
          onPosition?.call(AppLocationResult.failed(
            'GPS گوشی خاموش است. پس از روشن‌شدن خودکار متصل می‌شود.',
          ));
        } else {
          unawaited(recheck(requestPermission: true));
        }
      },
      onError: (Object error) {
        // The periodic recheck is an independent recovery route.
        onPosition?.call(AppLocationResult.failed(
          'خطا در بررسی وضعیت GPS: $error',
        ));
        unawaited(_serviceSubscription?.cancel());
        _serviceSubscription = null;
      },
    );

    _recoveryTimer = Timer.periodic(const Duration(seconds: 10), (_) {
      unawaited(recheck());
    });
    unawaited(recheck(requestPermission: true));
  }

  /// Called after Location is switched on and when the app is resumed.
  /// The stream is explicitly reopened if it failed while Location was off.
  Future<void> recheck({bool requestPermission = false}) async {
    if (!_watching) return;
    final generation = _generation;
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        _latest = null;
        return;
      }
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied && requestPermission) {
        // When GPS was disabled at connection time, no permission dialog was
        // shown. Ask once on the ON event / app resume, never on timer ticks.
        await refresh();
        permission = await Geolocator.checkPermission();
      }
      if (permission != LocationPermission.always &&
          permission != LocationPermission.whileInUse) return;
      if (!_watching || generation != _generation) return;

      await _ensurePositionStream(generation);
      if (!_watching || generation != _generation) return;
      // Update even for a stationary phone: distanceFilter alone might never
      // emit after Location is enabled and the phone does not move.
      await refresh();
    } catch (_) {
      // Retry on the next service-status event, resume, or 10 s tick.
    }
  }

  Future<void> _ensurePositionStream(int generation) async {
    if (_positionSubscription != null || _openingStream ||
        !_watching || generation != _generation) return;
    _openingStream = true;
    try {
      if (!await Geolocator.isLocationServiceEnabled() ||
          !_watching || generation != _generation) return;
      _positionSubscription = Geolocator.getPositionStream(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          distanceFilter: 3,
        ),
      ).listen(
        (position) {
          if (_watching && generation == _generation) {
            _remember(AppLocationResult.success(position));
          }
        },
        onError: (Object error) {
          if (!_watching || generation != _generation) return;
          final old = _positionSubscription;
          _positionSubscription = null;
          if (old != null) unawaited(old.cancel());
          onPosition?.call(AppLocationResult.failed('جریان GPS قطع شد: $error'));
          // Recovery timer/service-status event will open a NEW stream.
        },
        onDone: () {
          if (_watching && generation == _generation) {
            _positionSubscription = null;
          }
        },
        cancelOnError: true,
      );
    } catch (_) {
      _positionSubscription = null;
    } finally {
      _openingStream = false;
    }
  }

  void _remember(AppLocationResult result) {
    if (result.success && isUsableAt(result, DateTime.now())) {
      _latest = result;
    }
    onPosition?.call(result);
  }

  AppLocationResult? snapshotAt(DateTime receivedAt) {
    final candidate = _latest;
    return candidate != null && isUsableAt(candidate, receivedAt)
        ? candidate
        : null;
  }

  static bool isUsableAt(AppLocationResult result, DateTime receivedAt) {
    if (!result.success) return false;
    final lat = result.latitude;
    final lon = result.longitude;
    final accuracy = result.accuracy;
    final capturedAt = result.capturedAt;
    if (lat == null || lon == null || accuracy == null || capturedAt == null ||
        !lat.isFinite || !lon.isFinite || !accuracy.isFinite ||
        lat.abs() > 90 || lon.abs() > 180 || (lat == 0 && lon == 0) ||
        accuracy < 0 || accuracy > maxAccuracyMeters) return false;
    final age = receivedAt.difference(capturedAt);
    return age >= const Duration(seconds: -2) && age <= maxFixAge;
  }

  Future<void> stopWatching() async {
    _watching = false;
    ++_generation;
    _recoveryTimer?.cancel();
    _recoveryTimer = null;
    final position = _positionSubscription;
    final service = _serviceSubscription;
    _positionSubscription = null;
    _serviceSubscription = null;
    await position?.cancel();
    await service?.cancel();
    _latest = null;
  }
}
